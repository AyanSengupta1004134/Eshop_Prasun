package com.tcs.eshop.utilities;

/**
 * Created by 986719 on 9/17/2015.
 */
public class ApplicationConstant {
    public static class DataBaseConstant{
        //database name
        public static String DATABASE_NAME = "ESHOP_DATABASE";


        //version
        public static int DATA_BASE_VERSION = 2;


        //table names
        public static String CUSTOMER_TABLE = "TABLE_CUSTOMER";
        public static String PRODUCT_TABLE = "TABLE_PRODUCT";
       // public static String CART_TABLE = "TABLE_CART";
        public static String WISH_LIST_TABLE = "TABLE_WISH_LIST";
       // public static String REVIEW_TABLE = "TABLE_REVIEW";
        public static String ORDER_TABLE = "TABLE_ORDER";





        //Product table column names
        public static String PRODUCT_ID = "product_id";
        public static String PRODUCT_NAME = "product_name";
        public static String PRODUCT_CATEGORY = "product_category";
        public static String PRODUCT_SUBCATEGORY = "product_subcategory";
        public static String PRODUCT_PRICE = "product_price";
        public static String PRODUCT_IMAGE = "product_image";
        public static String PRODUCT_QTY_AVAILABLE = "product_qty_available";

        //Order table columns
        public static String ORDER_CODE = "order_code";
        public static String ORDER_CUSTOMER_NO = "customer_no";
        public static String ORDER_PRODUCT_CODE = "product_code";
        public static String ORDER_NO_OF_ITEMS = "ordered_no_of_items";
        public static String ORDER_DELIVERY_DATE = "delivery_date";




        //cart table columns


        //wishlist table columns




        public static String SELECT_CUSTOMER_TABLE = "SELECT * FROM "+ CUSTOMER_TABLE;

        public static String DROP_CUSTOMER_TABLE = "DROP TABLE IF EXISTS "+CUSTOMER_TABLE;
        public static class ProductTable
        {
            public static String PRODUCT_TABLE = "TABLE_PRODUCT";
            public static String PRODUCT_ID = "product_id";
            public static String PRODUCT_NAME = "product_name";
            public static String PRODUCT_CATEGORY = "product_category";
            public static String PRODUCT_SUBCATEGORY = "product_subcategory";
            public static String PRODUCT_PRICE = "product_price";
            public static String PRODUCT_IMAGE = "product_image";
            public static String PRODUCT_QTY_AVAILABLE = "product_qty_available";
            public static String PRODUCT_DESCRIPTION = "product_description";
            //Create querry
            public static String CREATE_PRODUCT_TABLE="CREATE TABLE "+PRODUCT_TABLE+"("+PRODUCT_ID+
                    " INTEGER PRIMARY KEY AUTOINCREMENT,"+PRODUCT_NAME+" TEXT,"+PRODUCT_CATEGORY+" TEXT,"+PRODUCT_SUBCATEGORY+
                    " TEXT,"+PRODUCT_PRICE+" FLOAT,"+PRODUCT_IMAGE+" TEXT,"+PRODUCT_QTY_AVAILABLE+" INTEGER," + PRODUCT_DESCRIPTION + " TEXT);";
            public static String DROP_PRODUCT_TABLE = "DROP TABLE IF EXISTS "+PRODUCT_TABLE;

        }
        public static class ReviewTable{
            public static String REVIEW_TABLE = "TABLE_REVIEW";
            //review table columns
            public static String REVIEW_ID = "review_id";
            public static String REVIEW_CUSTOMER_NO = "review_customer_no";
            public static String REVIEW_PRODUCT_CODE = "review_product_code";
            public static String REVIEW_DETAIL = "review_detail";

            public static String CREATE_RVIEW_TABLE = "CREATE TABLE "+REVIEW_TABLE+ "(" + REVIEW_ID +" INTEGER PRIMARY KEY AUTOINCREMENT,"+
                    REVIEW_CUSTOMER_NO + " INTEGER,"+REVIEW_PRODUCT_CODE + " INTEGER,"+ REVIEW_DETAIL + " TEXT)";

            public static String DROP_REVIEW_TABLE = "DROP TABLE IF EXISTS "+REVIEW_TABLE;

        }
        public static class CustomerTable
        {

            public static String CUSTOMER_TABLE = "TABLE_CUSTOMER";
            //customer column names
            public static String CUSTOMER_ID = "customer_id";
            public static String CUSTOMER_FIRST_NAME = "first_name";
            public static String CUSTOMER_LAST_NAME = "last_name";
            public static String CUSTOMER_EMAIL_ID = "email_id";
            public static String CUSTOMER_PHONE_NO = "phone_no";
            public static String CUSTOMER_QUESTION = "security_question";
            public static String CUSTOMER_ANSWER = "anaser";
            //public static String CUSTOMER_ADDRESS = "address";
            //public static String CUSTOMER_CITY = "city";
            //public static String CUSTOMER_STATE = "state";
            //public static String CUSTOMER_PIN_CODE = "pin_code";
            public static String CUSTOMER_PASSWORD = "password";
            //creation query
            public static String CREATE_CUSTOMER_TABLE = "CREATE TABLE "+ CUSTOMER_TABLE +"("+CUSTOMER_ID+
                    " INTEGER PRIMARY KEY AUTOINCREMENT,"+CUSTOMER_FIRST_NAME +" TEXT,"+CUSTOMER_LAST_NAME+" TEXT,"+
                    CUSTOMER_EMAIL_ID+" TEXT UNIQUE,"+CUSTOMER_PHONE_NO+" TEXT,"+CUSTOMER_QUESTION+" TEXT,"+CUSTOMER_ANSWER+" TEXT,"+
                    " TEXT,"+CUSTOMER_PASSWORD+" TEXT)";
            public static String DROP_CUSTOMER_TABLE = "DROP TABLE IF EXISTS "+CUSTOMER_TABLE;
        }
        public static class CartTable
        {
            public static String CART_TABLE = "TABLE_CART";
            public static String CART_CUSTOMER_NO = "cart_customer_no";
            public static String CART_PRODUCT_CODE = "cart_product_code";
            public static String CART_NO_OF_ITEMS = "cart_no_of_items";

            public static String DROP_CART_TABLE = "DROP TABLE IF EXISTS "+CART_TABLE;
            public static String CREATE_CART_TABLE = "CREATE TABLE "+CART_TABLE+ "("+ CART_CUSTOMER_NO +" INTEGER,"+
                    CART_PRODUCT_CODE + " INTEGER,"+CART_NO_OF_ITEMS + " INTEGER, PRIMARY KEY("+CART_CUSTOMER_NO+","+CART_PRODUCT_CODE+"))";

        }
        public static class WishlistTable{
            public static String WISH_LIST_TABLE = "TABLE_WISH_LIST";
            //wishlist table columns
            public static String WISHLIST_CUSTOMER_NO = "wishlist_customer_no";
            public static String WISHLIST_PRODUCT_CODE = "wishlist_product_code";
            public static String DROP_WISHLIST_TABLE = "DROP TABLE IF EXISTS "+WISH_LIST_TABLE;
            public static String CREATE_WISHLIST_TABLE = "CREATE TABLE "+ WISH_LIST_TABLE +"(" + WISHLIST_CUSTOMER_NO +" INTEGER,"+
                    WISHLIST_PRODUCT_CODE +" INTEGER, PRIMARY KEY(" + WISHLIST_CUSTOMER_NO + "," + WISHLIST_PRODUCT_CODE + "))";
        }
        public static class AddressTable{
            public static String ADDRESS_TABLE = "TABLE_ADDRESS";
            //address table columns
            public static String ADDRESS_ID = "address_id";
            public static String ADDRESS_CUSTOMER_NO = "address_customer_no";
            public static String ADDRESS_CUSTOMER_NAME = "address_customer_name";
            public static String ADDRESS_CUSTOMER_ADDRESS = "address_customer_address";
            public static String ADDRESS_CUSTOMER_PIN = "address_customer_pin";
            public static String ADDRESS_CUSTOMER_PHONE_NO = "address_customer_phone_no";
            public static String ADDRESS_CUSTOMER_CITY = "address_customer_city";
            public static String ADDRESS_CUSTOMER_STATE = "address_customer_state";

            public static String CREATE_ADDRESS_TABLE = "CREATE TABLE "+ ADDRESS_TABLE+ "("+ ADDRESS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    ADDRESS_CUSTOMER_NO+ " INTEGER," + ADDRESS_CUSTOMER_NAME + " TEXT," + ADDRESS_CUSTOMER_ADDRESS + " TEXT,"+
                    ADDRESS_CUSTOMER_PIN+ " INTEGER," + ADDRESS_CUSTOMER_PHONE_NO + " TEXT," + ADDRESS_CUSTOMER_CITY + " TEXT,"+
                    ADDRESS_CUSTOMER_STATE +" TEXT)";





            public static String DROP_ADDRESS_TABLE = "DROP TABLE IF EXISTS "+ADDRESS_TABLE;
        }
        public static class PaymentTable
        {
            public static String PAYMENT_TABLE = "TABLE_PAYMENT";
            //Payment table column names
            public static String CARD_NUMBER = "card_number";
            public static String CARD_TYPE = "card_type";
            public static String EXPIRY_MONTH = "expiry_month";
            public static String EXPIRY_YEAR = "expiry_year";
            public static String PAYMENT_CUSTOMER_NO = "payment_customer_no";

            public static String CREATE_PAYMENT_TABLE = "CREATE TABLE "+PAYMENT_TABLE+ "("+ PAYMENT_CUSTOMER_NO +" INTEGER,"+
                    CARD_NUMBER + " TEXT,"+CARD_TYPE + " TEXT,"+EXPIRY_MONTH +" TEXT,"+EXPIRY_YEAR +" TEXT, PRIMARY KEY("+PAYMENT_CUSTOMER_NO+","+CARD_TYPE+","+CARD_NUMBER+"))";

            public static String DROP_PAYMENT_TABLE = "DROP TABLE IF EXISTS "+PAYMENT_TABLE;


        }
    }


    public static class FragmentConstant{
        public static String states[]={"select","Andhra Pradesh" ,
                "Arunachal Pradesh " ,
                "Assam " ,
                "Bihar " ,
                "Chhattisgarh " ,
                "Goa " ,
                "Gujarat " ,
                "Haryana " ,
                "Himachal Pradesh " ,
                "Jammu & Kashmir " ,
                "Jharkhand " ,
                "Karnataka " ,
                "Kerala " ,
                "Madhya Pradesh " ,
                "Maharashtra " ,
                "Manipur " ,
                "Meghalaya " ,
                "Mizoram " ,
                "Nagaland " ,
                "Odisha (Orissa) " ,
                "Punjab " ,
                "Rajasthan " ,
                "Sikkim " ,
                "Tamil Nadu " ,
                "Telangana " ,
                "Tripura " ,
                "Uttar Pradesh " ,
                "Uttarakhand " ,
                "West Bengal"  };
        public static String questions[]={"Select Security Question","What was your childhood nickname?","What was your favorite sport in school?",
                "What is your mothers maiden name?","What primary school did you attend?"};

    }
    public class ErrorCaonstants
    {
        public static final String REQUIRED_FIELD="Please Enter a Value";
        public static final String PHONE_Field="Phone no must be 10 digit long";
        public static final String PASSWORD_FIELD="length must be at least 8 characters";

    }
}
