package com.tcs.eshop.adapter;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.R;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by 972509 on 9/22/2015.
 */
public class SearchAdapter extends BaseAdapter {


    ArrayList<Product>  mProductList;
    Context mContext;
    TextView mProductname,mProductPrice;
    ImageView mProductImage;
    public SearchAdapter(Context context,ArrayList<Product> products){
        mContext = context;
        mProductList = products;
    }

    public void setmProductList(ArrayList<Product> mProductList) {
        this.mProductList = mProductList;
    }

    public ArrayList<Product> getmProductList() {
        return mProductList;
    }

    @Override
    public int getCount() {
        return mProductList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater= (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if(view==null){
            view = inflater.inflate(R.layout.search_single_row,viewGroup,false);
        }
        initViews(view,i);
        return view;
    }

    public void initViews(View view,int i){
        mProductname = (TextView)view.findViewById(R.id.searchProductName);
        mProductPrice = (TextView)view.findViewById(R.id.searchProductPrice);
        mProductImage = (ImageView)view.findViewById(R.id.searchItemImage);

        mProductname.setText(mProductList.get(i).getProductName());
        mProductPrice.setText(String.valueOf(mProductList.get(i).getProductPrice()));
        File folder =mContext.getExternalFilesDir("contactimages");

        File file=new File(folder,mProductList.get(i).getProductImagePath());
        Log.d("path", file.getAbsolutePath());
        mProductImage.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
    }
}
