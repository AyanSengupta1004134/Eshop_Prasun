package com.tcs.eshop.EshopClasses;

import java.io.Serializable;

/**
 * Created by 986603 on 19-09-2015.
 */
public class Cart implements Serializable {
    private int customerId;
    private int productCode;
    private int noOfItems;

    public Cart(int customerId, int productCode, int noOfItems) {
        this.customerId = customerId;
        this.productCode = productCode;
        this.noOfItems = noOfItems;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getProductCode() {
        return productCode;
    }

    public void setProductCode(int productCode) {
        this.productCode = productCode;
    }

    public int getNoOfItems() {
        return noOfItems;
    }

    public void setNoOfItems(int noOfItems) {
        this.noOfItems = noOfItems;
    }
}
