package com.tcs.eshop.fragments;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.R;
import com.tcs.eshop.database.EshopSqlHelper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by 986719 on 9/17/2015.
 */
public class AdminFragment extends Fragment {
    EditText mEditProductName, mEditProductCategory, mEditProductSubCategory, mEditProductPrice, mEditProductQtyAvailable,mEditProductDescription;
    Button mAddProduct;
    EshopSqlHelper mEshopSqlHelper;
    String mProductImagePath;
    ImageButton mSelectImageButton;
    byte []img;
    private static int RESULT_LOAD_IMAGE = 1;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        img=null;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.admin_fragment, container, false);
        initViews(view);

        return view;
    }

    /**
     * Description: Used to initialise all the views in the layout
     * @param view: View object representing the layout
     */
    public void initViews(View view)
    {
        mEditProductName= (EditText) view.findViewById(R.id.productNameEdit);
        mEditProductCategory= (EditText) view.findViewById(R.id.categoryEdit);
        mEditProductSubCategory= (EditText) view.findViewById(R.id.subcategoryEdit);
        mEditProductPrice= (EditText) view.findViewById(R.id.priceEdit);
        mEditProductQtyAvailable= (EditText) view.findViewById(R.id.qtyEdit);
        mEditProductDescription=(EditText) view.findViewById(R.id.desCription);
        mAddProduct= (Button) view.findViewById(R.id.addProductButton);
        mSelectImageButton= (ImageButton) view.findViewById(R.id.selectProductImage);
        mSelectImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent selectPicIntent = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(selectPicIntent, RESULT_LOAD_IMAGE);
            }
        });
        mAddProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mEshopSqlHelper = EshopSqlHelper.getInstance(getActivity());
                if (img == null) {
                    img = getDefaultImage();
                }
                mProductImagePath = mEditProductName.getText().toString() + "_" + mEditProductCategory.getText().toString() +".PNG";
                writeExternalStoragePrivate(img, mProductImagePath);
                mEshopSqlHelper.insertTable(new Product(mEditProductName.getText().toString(), mEditProductCategory.getText().toString(),
                        mEditProductSubCategory.getText().toString(), Float.valueOf(mEditProductPrice.getText().toString()),
                        mProductImagePath, Integer.parseInt(mEditProductQtyAvailable.getText().toString()),mEditProductDescription.getText().toString()));
            }
        });
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String imagePathText;
        if (requestCode == RESULT_LOAD_IMAGE && resultCode ==getActivity().RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };

            Cursor cursor = getActivity().getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            imagePathText = cursor.getString(columnIndex);
            Bitmap bmp= BitmapFactory.decodeFile(imagePathText);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.PNG, 100, baos);
            bmp=decodeSampledBitmapFromByteArray(baos.toByteArray(), 100, 100);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, baos1);
            img=baos1.toByteArray();
            cursor.close();
            mSelectImageButton.setImageBitmap(bmp);

        }


    }

    /**
     * Description : Used for scaling down the size of an image
     * @param bytes : byte array representation of an image
     * @param reqWidth :scaling width
     * @param reqHeight:scaling height
     * @return: Bitmap representation of the scaled image
     */
    public static Bitmap decodeSampledBitmapFromByteArray(byte bytes[],
                                                          int reqWidth, int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return   BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
    }

    /**
     * Description: Used for getting the sample size of the image
     * @param options: Option object
     * @param reqWidth: scaling width
     * @param reqHeight: scaling height
     * @return
     */
    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

    /**
     *Description: Used for creating a file for the image selected by admin
     * @param bytes: byte array representation of an image
     * @param fileName: name of file
     * @return: bolean value indicating whether file is created successfully or not
     */
    public boolean writeExternalStoragePrivate(byte bytes[],String fileName)
    {
        File folder = getActivity().getExternalFilesDir("contactimages");
        File file=new File(folder,fileName);
        if(file.exists())
            return false;
        FileOutputStream fos=null;
        boolean flag=true;
        try {
            fos=new FileOutputStream(file,true);
            fos.write(bytes);
            //fos.write(-2);

        } catch (FileNotFoundException e) {
            Log.d("EXCEPTION", "" + e);
            flag=false;
        } catch (IOException e) {
            Log.d("EXCEPTION", "" + e);
            flag=false;
        }
        finally {
            if(fos!=null)
                try {
                    fos.close();
                } catch (IOException e) {
                    Log.d("EXCEPTION", "" + e);
                    flag=false;
                }
        }

        return flag;
    }

    /**
     * Description: Used to get a default image
     * @return :byte array representation of the image
     */
    public byte[] getDefaultImage()
    {
        Bitmap bmp= ((BitmapDrawable)mSelectImageButton.getDrawable()).getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, baos);
        return baos.toByteArray();
    }
}
