package com.tcs.eshop.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.TextView;

import com.tcs.eshop.R;
import com.tcs.eshop.adapter.GridAdapter;

/**
 * Created by 986719 on 9/16/2015.
 */
public class CategoryFragment extends Fragment {
    GridView mGridView;
    String mCategory;
    TextView textView;

    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mCategory=getArguments().getString("category");

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.category_fragment, container, false);
       initViews(view);
        return view;
    }
    public void initViews(View view)
    {
        mGridView= (GridView) view.findViewById(R.id.gridView);
        mGridView.setAdapter(new GridAdapter(getActivity(),mCategory));
        textView= (TextView) view.findViewById(R.id.category);
        textView.setText(mCategory);
    }

}
