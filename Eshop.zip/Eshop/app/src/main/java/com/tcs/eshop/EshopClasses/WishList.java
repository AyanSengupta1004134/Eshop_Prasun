package com.tcs.eshop.EshopClasses;

import java.io.Serializable;

/**
 * Created by 986603 on 9/21/2015.
 */
public class WishList implements Serializable{
    private int customerId;
    private int productId;

    public WishList(int customerId, int productId) {
        this.customerId = customerId;
        this.productId = productId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }
}
