package com.tcs.eshop.fragments;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.tcs.eshop.EshopClasses.Customer;
import com.tcs.eshop.EshopClasses.Product;
import  com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.adapter.SearchAdapter;
import com.tcs.eshop.adapter.SliderAdapter;
import com.tcs.eshop.adapter.SwipeAdapter;
import com.tcs.eshop.utilities.*;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by 986719 on 9/16/2015.
 */
public class HomeFragment extends android.support.v4.app.Fragment {
    ViewPager mViewPager1,mViewPager2,mViewPager3,mViewPager4,mViewPager5,mSliderPager;
    int currentPage=0;
    Timer mSwipeTimer;
    //ActionBarActivity mActionBarActivity;
    int mCustId;
    TextView mNavUserText;
    ArrayList<Customer> mCustomerList;
    DatabaseCaller mDatabaseCaller;
    EditText mSearchEdit;
    ListView mListView;
    PopupWindow popupWindow;
    ArrayList<Product> mProductlist=new ArrayList<Product>();
    SearchAdapter mSearchAdapter;
    MainActivity mainActivity;
    String s[]={"Electronics","LifeStyle","Automotive","Home & Furniture","Books"};
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
        mCustId=getActivity().getSharedPreferences("login", Context.MODE_PRIVATE).getInt("custId", -1);
        mDatabaseCaller=new DatabaseCaller((MainActivity)getActivity());
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view=inflater.inflate(R.layout.home_fragment, container, false);


        initViews(view);


        setSearch(container, view);

        final SliderAdapter sliderAdapter=new SliderAdapter(getActivity());
        mSliderPager.setAdapter(sliderAdapter);
        mSwipeTimer = new Timer();
        mSwipeTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                getActivity().runOnUiThread(new Runnable() {

                    @Override
                    public void run() {

                        if (currentPage == sliderAdapter.getCount()) {
                            currentPage = 0;
                        }
                        mSliderPager.setCurrentItem(currentPage++, true);
                    }
                });
            }
        }, 500, 3000);
        return view;
    }


    /**
     * Description: Used to initialise search parameters and setting text watcher
     * @param container
     * @param view
     */
    private void setSearch(ViewGroup container, final View view) {
        LayoutInflater inflater1 = (LayoutInflater)getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View layout = inflater1.inflate(R.layout.search_fragment,container,false);
        mListView = (ListView) layout.findViewById(R.id.searchListView);

        mListView.setDividerHeight(2);
        mSearchAdapter = new SearchAdapter(getActivity(),mProductlist);
        mListView.setAdapter(mSearchAdapter);
        popupWindow = new PopupWindow(layout);

        popupWindow.setWidth(container.getWidth());
        popupWindow.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        popupWindow.setInputMethodMode(PopupWindow.INPUT_METHOD_NEEDED);

        mSearchEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                //EditText searchEdittext = (EditText)view.findViewById(R.id.searchText);
                String searchString = editable.toString();
                if (!searchString.isEmpty()) {
                    mProductlist = mDatabaseCaller.searchProduct(searchString);
                    //mEshopSqlHelper.selectTable(ApplicationConstant.DataBaseConstant.ProductTable.PRODUCT_NAME + " LIKE '%" + searchString + "%'", null);
                    if (mProductlist.size() > 0) {
                        mSearchAdapter.setmProductList(mProductlist);
                        mSearchAdapter.notifyDataSetChanged();
                        popupWindow.showAsDropDown(view.findViewById(R.id.searchText), 0, 0);
                    } else {
                        if (popupWindow.isShowing()) {
                            popupWindow.dismiss();
                        }
                    }
                } else {
                    if (popupWindow.isShowing()) {
                        popupWindow.dismiss();
                    }
                }
            }
        });
       mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //android.support.v4.app.Fragment fragment = new DetailsFragment();
                Bundle bundle = new Bundle();
                bundle.putSerializable("object", mSearchAdapter.getmProductList().get(i));
                //Toast.makeText(getActivity(), "Name=" + mSearchAdapter.getmProductList().get(i).getProductName(), Toast.LENGTH_LONG).show();
                //fragment.setArguments(bundle);
                mainActivity.changeFragment(DetailsFragment.class, bundle, true, DetailsFragment.class.getName());

                //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, fragment, "details").addToBackStack("home").commit();
                popupWindow.dismiss();
            }
        });

        mSearchEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {

                if (popupWindow.isShowing()) {
                    popupWindow.dismiss();
                }
            }
        });
    }

    /**
     * Description: Used for Initializing the views
     * @param view
     */
    private void initViews(View view) {
        FragmentManager fragmentManager=getChildFragmentManager();
        mSearchEdit = (EditText)view.findViewById(R.id.searchText);
        mViewPager1= (ViewPager) view.findViewById(R.id.viewpager1);
        mViewPager1.setAdapter(new SwipeAdapter(fragmentManager,s[0]));
        mViewPager2= (ViewPager)view.findViewById(R.id.viewpager2);
        mViewPager2.setAdapter(new SwipeAdapter(fragmentManager,s[1]));
        mViewPager3= (ViewPager)view.findViewById(R.id.viewpager3);
        mViewPager3.setAdapter(new SwipeAdapter(fragmentManager,s[2]));
        mViewPager4= (ViewPager)view.findViewById(R.id.viewpager4);
        mViewPager4.setAdapter(new SwipeAdapter(fragmentManager, s[3]));
        mViewPager5= (ViewPager)view.findViewById(R.id.viewpager5);
        mViewPager5.setAdapter(new SwipeAdapter(fragmentManager, s[4]));

        mSliderPager= (ViewPager)view.findViewById(R.id.sliderpager);
        if(mCustId!=-1) {
            mNavUserText = (TextView) getActivity().findViewById(R.id.navUserId);
           setUserName();
        }
    }


    /**
     * Description: Used for Setting The userName in navigation drawer
     */
    public void setUserName()
    {

        if(mCustId!=-1) {
            String name=mDatabaseCaller.getCustomerName(mCustId);
            if (!name.isEmpty())
            {
                mNavUserText.setText("Hi "+name);
            }
        }
    }
    @Override
    public void onStop() {
        super.onStop();
        mSwipeTimer.cancel();
        mSearchEdit.setText("");
        MainActivity mainActivity= (MainActivity) getActivity();
        if(!mainActivity.ismTablet()) {
            mainActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            mainActivity.getmActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
            mainActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            mainActivity.getmActionBarDrawerToggle().syncState();

        }
    }
    @Override
    public void onResume() {
        super.onResume();

        if(popupWindow.isShowing()){
            popupWindow.dismiss();
        }

            MainActivity mainActivity = (MainActivity) getActivity();
        if(!mainActivity.ismTablet()) {
            mainActivity.getSupportActionBar().setHomeButtonEnabled(true);
            mainActivity.getmActionBarDrawerToggle().setDrawerIndicatorEnabled(true);
            mainActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            mainActivity.getmActionBarDrawerToggle().syncState();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();



    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }
}
