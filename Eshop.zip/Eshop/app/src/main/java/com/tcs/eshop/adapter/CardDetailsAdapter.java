package com.tcs.eshop.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.tcs.eshop.EshopClasses.Customer;
import com.tcs.eshop.EshopClasses.Payment;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;

import java.util.ArrayList;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.*;
import com.tcs.eshop.utilities.DatabaseCaller;

/**
 * Created by 986719 on 9/25/2015.
 */
public class CardDetailsAdapter extends BaseAdapter {
   Context context;
    TextView mCardNoText;
    public ArrayList<Payment> mpaymentArrayList;
    String mCardType;
    ImageView mDeleteImageView;
    DatabaseCaller mDatabaseCaller;
    int mCustomerId;

    public CardDetailsAdapter( Context context,String cardType)
    {
        this.context=context;
        mDatabaseCaller=new DatabaseCaller((MainActivity)context);
        mCustomerId=context.getSharedPreferences("login", Context.MODE_PRIVATE).getInt("custId", -1);
        mCardType=cardType;
        mpaymentArrayList=new ArrayList<>();
        mpaymentArrayList =mDatabaseCaller.getCardList(mCustomerId,mCardType);
        Log.d("card","card no:"+mpaymentArrayList.size());
    }
    @Override
    public int getCount() {
        return mpaymentArrayList.size();
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        mpaymentArrayList =mDatabaseCaller.getCardList(mCustomerId,mCardType);

    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        final int i1=i;
        LayoutInflater layoutInflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if(view==null)
        {
            view=layoutInflater.inflate(R.layout.card_list, viewGroup, false);
        }

        mCardNoText= (TextView) view.findViewById(R.id.cardNoText);
        mDeleteImageView= (ImageView) view.findViewById(R.id.cardDeleteImage);
        mDeleteImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               mDatabaseCaller.deleteCard(mCustomerId,mpaymentArrayList.get(i1).getCardNumber());
                notifyDataSetChanged();
            }
        });
        mCardNoText.setText(mpaymentArrayList.get(i).getCardNumber());
        return view;
    }
}
