package com.tcs.eshop.utilities;

import com.tcs.eshop.EshopClasses.Address;
import com.tcs.eshop.EshopClasses.Cart;
import com.tcs.eshop.EshopClasses.Customer;
import com.tcs.eshop.EshopClasses.Payment;
import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.EshopClasses.Review;
import com.tcs.eshop.EshopClasses.WishList;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.*;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by 986719 on 10/1/2015.
 */
public class DatabaseCaller {
    EshopSqlHelper mEshopSqlHelper;
    public DatabaseCaller(MainActivity mainActivity)
    {
        mEshopSqlHelper=EshopSqlHelper.getInstance(mainActivity);
    }
    public String getCustomerName(int customerId)
    {
        ArrayList<Customer> mCustomerList;
        mCustomerList = mEshopSqlHelper.getAllCustomer(ApplicationConstant.DataBaseConstant.CustomerTable.CUSTOMER_ID + "=?", new String[]{String.valueOf(customerId)});
        return mCustomerList.get(0).getFirstName();
    }
    public int getCustomerId(String userId)
    {
        ArrayList<Customer> mCustomerList;
        mCustomerList = mEshopSqlHelper.getAllCustomer(ApplicationConstant.DataBaseConstant.CustomerTable.CUSTOMER_EMAIL_ID + "=? OR " + ApplicationConstant.DataBaseConstant.CustomerTable.CUSTOMER_PHONE_NO + "=?", new String[]{userId,userId});
        if(mCustomerList.size()<=0)
            return -1;
        return mCustomerList.get(0).getCustId();
    }
    public Customer getCustomer(int customerId)
    {
        ArrayList<Customer> mCustomerList;
        mCustomerList = mEshopSqlHelper.getAllCustomer(ApplicationConstant.DataBaseConstant.CustomerTable.CUSTOMER_ID + "=?", new String[]{String.valueOf(customerId)});
        return mCustomerList.get(0);
    }
    public void deleteCartItems(int custId,int productId)
    {
        mEshopSqlHelper.deleteCartItem(ApplicationConstant.DataBaseConstant.CartTable.CART_CUSTOMER_NO+"=? AND "+ ApplicationConstant.DataBaseConstant.CartTable.CART_PRODUCT_CODE+"=?",new String[]{String.valueOf(custId),String.valueOf(productId)});

    }
    public ArrayList<Cart> getCartList(int custId)
    {
        ArrayList<Cart> mCartlist;
        mCartlist=mEshopSqlHelper.selectTableCartTable(ApplicationConstant.DataBaseConstant.CartTable.CART_CUSTOMER_NO+"=?",new String[]{String.valueOf(custId)});
        return mCartlist;
    }
    public ArrayList<Cart> getCartList(int custId,int productId)
    {
        ArrayList<Cart> mCartlist;
        mCartlist=mEshopSqlHelper.selectTableCartTable(CartTable.CART_CUSTOMER_NO+"=? AND "+CartTable.CART_PRODUCT_CODE+"=?",new String[]{String.valueOf(custId),String.valueOf(productId)});
        return mCartlist;
    }
    public void updateProductNoOfItems(int newQty,int productId)
    {
        mEshopSqlHelper.updateProductNoOfItems(newQty, ProductTable.PRODUCT_ID + "=?", new String[]{String.valueOf(productId)});

    }

    public void insertCartDetails(int custId,int productId)
    {
        mEshopSqlHelper.insertCartTable(new Cart(custId, productId, 1));
    }
    public void insertWhishlistDetails(WishList wish)
    {
        mEshopSqlHelper.insertWishListTable(new WishList(wish.getCustomerId(), wish.getProductId()));
    }
    public void insertReview(Review review)
    {
        mEshopSqlHelper.insertReview(review);

    }
    public void updateProduct(int mNoOfItems,int custId,int productId)
    {
        mEshopSqlHelper.updateCartNoOfItems(mNoOfItems, CartTable.CART_CUSTOMER_NO + "=? AND " + CartTable.CART_PRODUCT_CODE + "=?", new String[]{String.valueOf(custId),
                String.valueOf(productId)});

    }
    public Product getProduct(int productId)
    {
        ArrayList<Product> temp;
        temp= mEshopSqlHelper.selectTable(ApplicationConstant.DataBaseConstant.ProductTable.PRODUCT_ID + "=?", new String[]{String.valueOf(productId)});
        return temp.get(0);
    }
    public boolean isProductExistsWishlist(int customerId,int productCode)
    {
        ArrayList<WishList> wishListArrayList;
        wishListArrayList=mEshopSqlHelper.selectTableWishListTable(WishlistTable.WISHLIST_CUSTOMER_NO + "=? AND " + WishlistTable.WISHLIST_PRODUCT_CODE + "=?", new String[]{String.valueOf(customerId), String.valueOf(productCode)});
        if(wishListArrayList.size()>0) {
            //mNoOfItems=wishListArrayList.get(0).getNoOfItems();
            return true;
        }
        return  false;
    }
    public ArrayList<Product> getProductList(String category)
    {
        ArrayList<Product> temp;
        temp= mEshopSqlHelper.selectTable(ProductTable.PRODUCT_CATEGORY + "=?", new String[]{category});
        return temp;
    }
    public ArrayList<Product> searchProduct(String searchString)
    {
        ArrayList<Product> mProductlist;
        mProductlist = mEshopSqlHelper.selectTable(ApplicationConstant.DataBaseConstant.ProductTable.PRODUCT_NAME + " LIKE '%" + searchString + "%'", null);
        return mProductlist;
    }
    public  ArrayList<Review> getReviewList(int productId)
    {
        ArrayList<Review> mReviewArrayList;
        mReviewArrayList= mEshopSqlHelper.selectTableReviewTable(ReviewTable.REVIEW_PRODUCT_CODE + "=?", new String[]{String.valueOf(productId)});
        return mReviewArrayList;
    }
    public ArrayList<Address> getAddressList(int custId)
    {
        ArrayList<Address> mAddressArrayList;
        mAddressArrayList=mEshopSqlHelper.selectTableAddressTable(AddressTable.ADDRESS_CUSTOMER_NO + "=?", new String[]{String.valueOf(custId)});
        return  mAddressArrayList;
    }
    public ArrayList<Payment> getCardList(int custId,String cardType)
    {
        ArrayList<Payment> mpaymentArrayList;
        mpaymentArrayList = mEshopSqlHelper.selectTablePaymentTable(PaymentTable.PAYMENT_CUSTOMER_NO + "=? AND " + PaymentTable.CARD_TYPE + "=?", new String[]{String.valueOf(custId), cardType});
        return mpaymentArrayList;
    }
    public void deleteCard(int custId,String cardNumber)
    {
        mEshopSqlHelper.deleteCardDetails(PaymentTable.PAYMENT_CUSTOMER_NO + "=? AND " + PaymentTable.CARD_NUMBER + "=?", new String[]{String.valueOf(custId), cardNumber});

    }
    public ArrayList<WishList> getWishList(int custId)
    {
        ArrayList<WishList> mWishListArrayList;
        mWishListArrayList = mEshopSqlHelper.selectTableWishListTable(ApplicationConstant.DataBaseConstant.WishlistTable.WISHLIST_CUSTOMER_NO + "=?", new String[]{String.valueOf(custId)});
        return mWishListArrayList;
    }
   public void deleteWishListItems(int custId,int productId)
   {
       mEshopSqlHelper.deleteWishListItem(WishlistTable.WISHLIST_CUSTOMER_NO + "=? AND " + WishlistTable.WISHLIST_PRODUCT_CODE + "=?", new String[]{String.valueOf(custId), String.valueOf(productId)});

   }
    public boolean isProductExists(int productId)
    {
        ArrayList<Product> temp;
        temp= mEshopSqlHelper.selectTable(ApplicationConstant.DataBaseConstant.ProductTable.PRODUCT_ID + "=?", new String[]{String.valueOf(productId)});
        if(temp.isEmpty()||temp.size()<=0)
            return false;
        return true;
    }
}
