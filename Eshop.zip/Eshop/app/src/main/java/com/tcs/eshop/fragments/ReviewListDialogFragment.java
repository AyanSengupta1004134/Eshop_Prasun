package com.tcs.eshop.fragments;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.tcs.eshop.EshopClasses.Review;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.utilities.DatabaseCaller;
import com.tcs.eshop.adapter.ReviewListAdapter;

import java.util.ArrayList;

/**
 * Created by 986719 on 9/19/2015.
 */
public class ReviewListDialogFragment extends DialogFragment {
    ListView mReviewListView;
    ArrayList<Review> mReviewArrayList;
    EshopSqlHelper mEshopSqlHelper;
    DatabaseCaller mDatabaseCaller;


    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle=getArguments();

        mDatabaseCaller=new DatabaseCaller((MainActivity)getActivity());
        mEshopSqlHelper=EshopSqlHelper.getInstance(getActivity());
        mReviewArrayList=mDatabaseCaller.getReviewList(bundle.getInt("productid"));
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //
        View view= inflater.inflate(R.layout.reviewlist_fragment, container, false);
        mReviewListView= (ListView) view.findViewById(R.id.reviewListFragment);
        mReviewListView.setAdapter(new ReviewListAdapter(getActivity(),mReviewArrayList));
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        //getDialog().setTitle("Reviews");
        //getDialog().getWindow().setLayout(500, ViewGroup.LayoutParams.WRAP_CONTENT);
    }
}
