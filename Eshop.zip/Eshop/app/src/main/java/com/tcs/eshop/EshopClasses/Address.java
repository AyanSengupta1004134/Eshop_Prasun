package com.tcs.eshop.EshopClasses;

/**
 * Created by 986465 on 9/22/2015.
 */
public class Address {
    private int adressId;
    private int customerId;
    private String name;
    private String address;
    private  int pincode;
    private String phoneNo;
    private String city;
    private String state;

    public Address(int adressId, int customerId, String name, String address, int pincode, String phoneNo, String city, String state) {
        this.adressId = adressId;
        this.customerId = customerId;
        this.name = name;
        this.address = address;
        this.pincode = pincode;
        this.phoneNo = phoneNo;
        this.city = city;
        this.state = state;
    }

    public Address(int customerId, String name, String address, int pincode, String phoneNo, String city, String state) {
        this.customerId = customerId;
        this.name = name;
        this.address = address;
        this.pincode = pincode;
        this.phoneNo = phoneNo;
        this.city = city;
        this.state = state;
    }

    public int getAdressId() {
        return adressId;
    }

    public void setAdressId(int adressId) {
        this.adressId = adressId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPincode() {
        return pincode;
    }

    public void setPincode(int pincode) {
        this.pincode = pincode;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
