package com.tcs.eshop.fragments;

/**
 * Created by 986719 on 9/18/2015.
 */


        import android.content.Context;
        import android.os.Bundle;
        import android.support.v4.app.Fragment;
        import android.util.Log;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Spinner;
        import android.widget.Toast;
        import com.tcs.eshop.EshopClasses.Customer;
        import com.tcs.eshop.R;
        import com.tcs.eshop.activities.MainActivity;
        import com.tcs.eshop.database.EshopSqlHelper;
        import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.CustomerTable;
        import com.tcs.eshop.utilities.ApplicationConstant;
        import com.tcs.eshop.utilities.ApplicationConstant.FragmentConstant;

        import java.util.ArrayList;
        import java.util.regex.Matcher;
        import java.util.regex.Pattern;


public class RegisterFragment extends Fragment {
    private Context mContext;
    private Button mRegisterBtn;
    private EditText mFirstName;
    private EditText mLastName;
    private EditText mMailId;
    private EditText mPhone;
    private EditText mPassword;
    private EditText mConfirmPassword;
    private Spinner mQuestions;
    private EditText mAnswer;
    String firstName;
    String lastName;
    String phoneNo;
    String mailId;
    String password;
    String confirmPassword;
    String question;
    String answer;
    EshopSqlHelper mEshopSqlHelper;
    ArrayList<Customer> cusList;
    MainActivity mainActivity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
    }

    public View onCreateView(LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.register_page,null);
        initViews(container, view);
        setListener(container);


        return view;
    }

    /**
     * Description: Used to set listeners
     * @param container: viewGroup
     */
    private void setListener(final ViewGroup container) {
        mRegisterBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {

                firstName = mFirstName.getText().toString();
                lastName = mLastName.getText().toString();
                phoneNo = mPhone.getText().toString();
                mailId = mMailId.getText().toString();
                password = mPassword.getText().toString();
                question = mQuestions.getSelectedItem().toString();
                answer = mAnswer.getText().toString();
                confirmPassword = mConfirmPassword.getText().toString();
                if (validate(container.getContext())) {

                    //Toast.makeText(getActivity(),"submitted",Toast.LENGTH_LONG).show();
                    //ckecking with the database
                    if (!isMailInDataBase(mailId)) {
                        if (!isPhoneInDataBase(phoneNo)) {
                            Toast.makeText(mContext, "Registered Succesfully" + " " + question, Toast.LENGTH_SHORT).show();

                            mEshopSqlHelper.insertCustomer(new Customer(firstName, lastName, mailId, phoneNo, question, answer, password));
                            //LoginFragment shopLoginFragment = new LoginFragment();
                            mainActivity.changeFragment(LoginFragment.class, null, true, LoginFragment.class.getName());

                            // getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, shopLoginFragment, "login").addToBackStack("register").commit();

                        } else {
                            Toast.makeText(mContext, "Phone no already exist", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(mContext, "mail ID already exist", Toast.LENGTH_LONG).show();
                    }

                } else {
                    Toast.makeText(mContext, "Registration failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * Description: Used to initialize the views
     * @param container: viewGroup
     * @param view: views
     */
    private void initViews(ViewGroup container, View view) {
        mContext=container.getContext();
        mEshopSqlHelper= EshopSqlHelper.getInstance(getActivity());
        mRegisterBtn = (Button)view.findViewById(R.id.register);
        mFirstName = (EditText)view.findViewById(R.id.etFirstName);
        mLastName = (EditText)view.findViewById(R.id.etLastName);
        mMailId = (EditText)view.findViewById(R.id.etEmail);
        mPhone = (EditText)view.findViewById(R.id.etPhoneNo);
        mQuestions = (Spinner)view.findViewById(R.id.security_ques);
        mAnswer = (EditText)view.findViewById(R.id.answer);
        mPassword = (EditText)view.findViewById(R.id.etPassword);
        mConfirmPassword = (EditText)view.findViewById(R.id.etConfirmPassword);
        mQuestions.setAdapter(new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, FragmentConstant.questions));
    }

    /**
     * Description:
     * @param context
     * @return
     */
    public boolean validate(Context context) {
        boolean flag = true;



        if(firstName.isEmpty()){
            mFirstName.setError("mandatory field");
            mFirstName.requestFocus();
            flag =  false;
        }
        else if(!isValidName(firstName)){
            mFirstName.setError("invalid first name");
            mFirstName.requestFocus();
            flag = false;
        }
        else if(lastName.isEmpty()){
            mLastName.setError("mandatory field");
            mLastName.requestFocus();
            flag = false;
        }
        else if(!isValidName(lastName)){
            mLastName.setError("invalid last name");
            mLastName.requestFocus();
            flag = false;
        }
        else {
            if (phoneNo.isEmpty() || !isValidNo(phoneNo)) {
                mPhone.setError("enter 10 digit phone no starting with 7 or 8 or 9");
                mPhone.requestFocus();
                flag = false;
            } else if (mailId.isEmpty() || !isValidMail(mailId)) {
                mMailId.setError(getString(R.string.isValidMail));
                flag = false;
            } else if (question.equals(getString(R.string.securityQuestionSelection))) {
                Toast.makeText(context, "Select security question", Toast.LENGTH_LONG).show();
                flag = false;
            } else if (answer.isEmpty()) {
                mAnswer.setError(getString(R.string.Mandatory));
                flag = false;
            } else if (password.isEmpty()) {

                mPassword.setError(getString(R.string.Mandatory));
                flag = false;
            } else if (password.length() < 8) {

                mPassword.setError(context.getString(R.string.passwordLength));
                flag = false;
            } else if (confirmPassword.isEmpty()) {
                mConfirmPassword.setError(getString(R.string.Mandatory));
                flag = false;
            } else {
                if(!validate(password,confirmPassword))
                {
                    flag=false;
                }
            }
        }
        return flag;
    }
    public boolean validate(String password,String confirmPassword)
    { Boolean flag=true;
        if (!password.equals(confirmPassword)) {
            mPassword.setText("");
            mConfirmPassword.setText("");
            Toast.makeText(mContext, R.string.passwordMismatch, Toast.LENGTH_LONG).show();
            flag = false;
        }
        return  flag;
    }
    public boolean isValidNo(String number) {
        String PHONE_PATTERN="^[789]\\d{9}$";
                //= "\\d{10}";
        Pattern pattern = Pattern.compile(PHONE_PATTERN);
        Matcher matcher = pattern.matcher(number);
        return matcher.matches();
    }

    public boolean isValidPin(String pin){
        String PIN_PATTERN = "\\d{6}";
        Pattern pattern = Pattern.compile(PIN_PATTERN);
        Matcher matcher = pattern.matcher(pin);
        return matcher.matches();
    }
    public boolean isValidName(String name){
        String NAME_PATTERN = "[a-zA-Z]*";
        Pattern pattern = Pattern.compile(NAME_PATTERN);
        Matcher matcher = pattern.matcher(name);
        return matcher.matches();
    }
    public boolean isValidMail(String mail){
        String MAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        Pattern pattern = Pattern.compile(MAIL_PATTERN);
        Matcher matcher = pattern.matcher(mail);
        return matcher.matches();
    }

    public boolean isMailInDataBase(String mailId){
        boolean flag = false;
        cusList = mEshopSqlHelper.getAllCustomer();
        if(cusList.size()!=0){
            for (int i=0;i<cusList.size();i++){
                Log.d("sovan",cusList.get(i).getEmailId());
                if(cusList.get(i).getEmailId().equals(mailId)){
                    flag = true;
                    break;
                }
            }
        }
        return flag;
    }

    public boolean isPhoneInDataBase(String phoneNo){
        boolean flag = false;
        cusList = mEshopSqlHelper.getAllCustomer();
        if(cusList.size()!=0){
            for (int i=0;i<cusList.size();i++){
                Log.d("sovan",cusList.get(i).getEmailId());
                if(cusList.get(i).getPhoneNo().equals(phoneNo)){
                    flag = true;
                    break;
                }
            }
        }
        return flag;
    }
}
