package com.tcs.eshop.fragments;

import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.utilities.ApplicationConstant;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.*;
import com.tcs.eshop.utilities.DatabaseCaller;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by 986719 on 9/16/2015.
 */
public class SwipeFragment1 extends Fragment {
    String mCategory;
    TextView mNameTextView1,mPriceTextView1,mNameTextView2,mPriceTextView2;
    ImageView mProductImageView1,mProductImageView2;
    ArrayList<Product> mProductArrayList;
    EshopSqlHelper mEshopSqlHelper;
    DatabaseCaller mDatabaseCaller;
    MainActivity mainActivity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
        mDatabaseCaller=new DatabaseCaller((MainActivity)getActivity());
        mEshopSqlHelper=EshopSqlHelper.getInstance(getActivity());
        mCategory=getArguments().getString("category");
        mProductArrayList=mDatabaseCaller.getProductList(mCategory);
    }

    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.swipe_fragment,container,false);
        initViews(view);
        if(mProductArrayList.size()>=2)
        {
            mNameTextView1.setText(mProductArrayList.get(0).getProductName());
            mNameTextView2.setText(mProductArrayList.get(1).getProductName());
            mPriceTextView1.setText(String.valueOf(mProductArrayList.get(0).getProductPrice()));
            mPriceTextView2.setText(String.valueOf(mProductArrayList.get(1).getProductPrice()));
            File folder =getActivity().getExternalFilesDir("contactimages");

            File file=new File(folder,mProductArrayList.get(0).getProductImagePath());
            Log.d("path", file.getAbsolutePath());
            mProductImageView1.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));

             file=new File(folder,mProductArrayList.get(1).getProductImagePath());
            Log.d("path", file.getAbsolutePath());
            mProductImageView2.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            setListener();


        }

        return view;
    }

    /**
     * Description: Used for initialising the views
     * @param view: View
     */
    private void initViews(View view) {
        mNameTextView1= (TextView) view.findViewById(R.id.swipeNameText1);
        mNameTextView2= (TextView) view.findViewById(R.id.swipeNameText2);
        mPriceTextView1= (TextView) view.findViewById(R.id.swipePriceText1);
        mPriceTextView2= (TextView) view.findViewById(R.id.swipePriceText2);
        mProductImageView1= (ImageView) view.findViewById(R.id.swipeImage1);
        mProductImageView2= (ImageView) view.findViewById(R.id.swipeImage2);
    }

    /**
     * Description: Used to set the listener
     */
    private void setListener() {
        mProductImageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Fragment fragment = new DetailsFragment();
                Bundle bundle = new Bundle();
                bundle.putSerializable("object", mProductArrayList.get(0));
                //fragment.setArguments(bundle);
                mainActivity.changeFragment(DetailsFragment.class, bundle, true, DetailsFragment.class.getName());

                //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, fragment, "details").addToBackStack("home").commit();
            }
        });
        mProductImageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Fragment fragment=new DetailsFragment();
                Bundle bundle=new Bundle();
                bundle.putSerializable("object", mProductArrayList.get(1));
                //fragment.setArguments(bundle);
                mainActivity.changeFragment(DetailsFragment.class, bundle, true, DetailsFragment.class.getName());

                //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout,fragment,"details").addToBackStack("home").commit();
            }
        });
    }
}