package com.tcs.eshop.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.tcs.eshop.EshopClasses.Address;
import com.tcs.eshop.EshopClasses.Customer;
import com.tcs.eshop.EshopClasses.Payment;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.utilities.DatabaseCaller;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by 986465 on 9/22/2015.
 */
public class ShipingFragment extends Fragment {
    String pincodeArray[];
    ArrayList<Address> mAddressArrayList;
    ListView mShipingListView;
    EshopSqlHelper mEshopSqlHelper;
    EditText mNameEdit,mAddEdit,mPinEdit,mPhoneNoEdit,mCityEdit,mStateEdit;
    String s[]={"ajay","ajay","ajay"};
    ArrayList<String> mStringArrayList;
    Customer mCustomer;
    Button mMakePayment;
    CheckBox mSaveAddressCheckBox;
    ArrayAdapter<String> mArrayAdapter;
    DatabaseCaller  mDatabaseCaller;
    MainActivity mainActivity;
    int mCustomerId;
    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
        mDatabaseCaller=new DatabaseCaller((MainActivity)getActivity());
        mCustomerId=getActivity().getSharedPreferences("login", Context.MODE_PRIVATE).getInt("custId", -1);

        mEshopSqlHelper=EshopSqlHelper.getInstance(getActivity());
        mCustomer=mDatabaseCaller.getCustomer(mCustomerId);
        mStringArrayList=new ArrayList<String>();
        mAddressArrayList=mDatabaseCaller.getAddressList(mCustomerId);
        getAddress();
        Log.d("size", "size 1=" + mAddressArrayList.size() + "id=" + mCustomer.getCustId());
        Log.d("size", "size 2=" + mStringArrayList.size());
    }

    /**
     * Description: Used for getting the partial address of delivery
     */
    public void getAddress()
    {
        String s="";
        for(int i=0;i<mAddressArrayList.size();i++)
        {
            s=mAddressArrayList.get(i).getAddress();
            if(s.length()>15)
                s=s.substring(0,15);
            mStringArrayList.add("Name: "+mAddressArrayList.get(i).getName()+"\n"+s+"...");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.shiping_fragment, container, false);
        initViews(view);

        return view;
    }

    /**
     * Description: Used for initialising the views
     * @param view
     */
    private void initViews(View view) {
        mShipingListView = (ListView) view.findViewById(R.id.shiping_listview);
        mShipingListView.setDividerHeight(2);
        LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mShipingListView.addFooterView(layoutInflater.inflate(R.layout.shiping_list_footer, null, false));
        mArrayAdapter=new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, mStringArrayList){
            @Override
            public void notifyDataSetChanged() {
                super.notifyDataSetChanged();
                mEshopSqlHelper=EshopSqlHelper.getInstance(getActivity());
                mCustomer=mDatabaseCaller.getCustomer(mCustomerId);
                mStringArrayList=new ArrayList<String>();
                mAddressArrayList=mDatabaseCaller.getAddressList(mCustomerId);
                getAddress();
            }
        };
        mShipingListView.setAdapter(mArrayAdapter);
        mNameEdit = (EditText) view.findViewById(R.id.shipping_nameEdit);
        mAddEdit = (EditText) view.findViewById(R.id.shipping_addressEdit);
        mPinEdit = (EditText) view.findViewById(R.id.shiping_pinEdit);
        mPhoneNoEdit = (EditText) view.findViewById(R.id.shipping_phoneEdit);
        mCityEdit = (EditText) view.findViewById(R.id.shipping_cityEdit);
        mStateEdit = (EditText) view.findViewById(R.id.shipping_stateEdit);
        mMakePayment = (Button) view.findViewById(R.id.shipping_payButton);
        mSaveAddressCheckBox= (CheckBox) view.findViewById(R.id.shipingcheckBox);
        setListener();
    }

    /**
     * Description: Used to set the listener
     */
    private void setListener() {
        mShipingListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                mNameEdit.setText(mAddressArrayList.get(i).getName());
                mAddEdit.setText(mAddressArrayList.get(i).getAddress());
                mPinEdit.setText(String.valueOf(mAddressArrayList.get(i).getPincode()));
                mPhoneNoEdit.setText(mAddressArrayList.get(i).getPhoneNo());
                mCityEdit.setText(mAddressArrayList.get(i).getCity());
                mStateEdit.setText(mAddressArrayList.get(i).getState());

            }
        });
        mMakePayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!isValid()||!isValidPincode())
                    return;
                if(mSaveAddressCheckBox.isChecked()) {
                    mEshopSqlHelper.insertAddressTable(new Address(mCustomer.getCustId(), mNameEdit.getText().toString(),
                            mAddEdit.getText().toString(), Integer.parseInt(mPinEdit.getText().toString()), mPhoneNoEdit.getText().toString(), mCityEdit.getText().toString(),
                            mStateEdit.getText().toString()));
                    Toast.makeText(getActivity(), R.string.addressSaved, Toast.LENGTH_SHORT).show();

                    mArrayAdapter.notifyDataSetChanged();
                }
                mainActivity.changeFragment(PaymentFragment.class, null, true, Payment.class.getName());

                //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new PaymentFragment(), "payment").addToBackStack("shiping").commit();

            }
        });
    }

    /**
     * Description: Used for validating the address fields
     * @return: boolean result
     */
    public boolean isValid()
    {
        boolean flag=true;
        String s="Please fill the details";
        if(mNameEdit.getText().toString().equals(""))
        {
            mNameEdit.setError(getString(R.string.Mandatory));
            flag=false;
        }
        else if(!isValidName(mNameEdit.getText().toString())){
            mNameEdit.setError("invalid last name");
            mNameEdit.requestFocus();
            flag = false;
        }
        if(mAddEdit.getText().toString().equals(""))
        {
            mAddEdit.setError(getString(R.string.Mandatory));
            flag=false;
        }
        if(mPinEdit.getText().toString().equals(""))
        {
            mPinEdit.setError(getString(R.string.Mandatory));
            flag=false;
        }
        else {
            if(!isValidPin(mPinEdit.getText().toString())){
                mPinEdit.setError(getString(R.string.invalidPin));
                flag = false;
            }
        }
        if(mPhoneNoEdit.getText().toString().equals(""))
        {
            mPhoneNoEdit.setError(getString(R.string.Mandatory));
            flag=false;
        }
        else {
            if(!isValidNo(mPhoneNoEdit.getText().toString())){
                mPhoneNoEdit.setError(getString(R.string.invalidPhoneNo));
                flag=false;
            }
        }
        if(mCityEdit.getText().toString().equals(""))
        {
            mCityEdit.setError(getString(R.string.Mandatory));
            flag=false;
        }
        if(mStateEdit.getText().toString().equals(""))
        {
            mStateEdit.setError(getString(R.string.Mandatory));
            flag=false;
        }

        return flag;
    }


    public boolean isValidNo(String number) {
        String PHONE_PATTERN = "^[789]\\d{9}$";
        Pattern pattern = Pattern.compile(PHONE_PATTERN);
        Matcher matcher = pattern.matcher(number);
        return matcher.matches();
    }

    public boolean isValidPin(String pin){
        String PIN_PATTERN = "\\d{6}";
        Pattern pattern = Pattern.compile(PIN_PATTERN);
        Matcher matcher = pattern.matcher(pin);
        return matcher.matches();
    }

    /**
     * Description: Used for validating the pincode field
     * @return: boolean result
     */
    public boolean isValidPincode()
    {
        boolean flag=true;
        if(!mPinEdit.getText().toString().isEmpty()){
            if(mPinEdit.getText().toString().length()!=6)
            {
                mPinEdit.setError(getString(R.string.ValidPincode));
                flag=false;

            }
            else {
                if (!isPinAvailable(mPinEdit.getText().toString())) {

                    mPinEdit.setError(getString(R.string.deliveryCheck));
                    flag=false;

                }
            }
        }
        else {
            flag=false;
            mPinEdit.setError(getString(R.string.pincodeEnter));
        }
        return  flag;
    }
    public boolean isValidName(String name){
        String NAME_PATTERN = "[a-zA-Z\\s]*";
        Pattern pattern = Pattern.compile(NAME_PATTERN);
        Matcher matcher = pattern.matcher(name);
        return matcher.matches();
    }

    /**
     * Description: Used for checking delivery option on the pincode
     * @param pin: Pincode
     * @return: boolean result
     */
    public boolean isPinAvailable(String pin){
        boolean flag = false;
        pincodeArray = getActivity().getResources().getStringArray(R.array.pincodes);
        for (int i=0;i<pincodeArray.length;i++) {
            if (pincodeArray[i].equals(pin)) {
                flag = true;
                break;
            }
        }
        return flag;
    }
}
