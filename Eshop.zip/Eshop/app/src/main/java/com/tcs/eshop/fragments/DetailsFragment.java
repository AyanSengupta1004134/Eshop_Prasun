package com.tcs.eshop.fragments;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.tcs.eshop.EshopClasses.Cart;
import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.EshopClasses.Review;
import com.tcs.eshop.EshopClasses.WishList;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.utilities.DatabaseCaller;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by 986719 on 9/16/2015.
 */
public class DetailsFragment extends Fragment {

//ListView mReviewListView;
    TextView mNameText,mPriceText,mDescriptionText,mStatusText;
   // String s[]={"Review1","Review2","Review3","Review4"};
    String pincodeArray[];
    Product mProduct;
    ImageView mProductImageView;
    EditText mReviewEdit,mPincodeEdit;
    Button mSubmitReviewButton,mShowReviewButton,mAddToCartButton,mAddToWishListButton,mBuyButton,mCheckPin;
    ArrayList<Cart> mCartlist;
    DatabaseCaller mDatabaseCaller;
    int mNoOfItems=0;
    int mCustomerId;
    int mTotalQty=0;
    MainActivity mainActivity;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.details_fragment, container, false);
        initViews(view);
        return view;
    }

    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
        mDatabaseCaller=new DatabaseCaller((MainActivity)getActivity());
        Bundle bundle=getArguments();
        mProduct=(Product)bundle.getSerializable("object");
       mCustomerId=getActivity().getSharedPreferences("login", Context.MODE_PRIVATE).getInt("custId", -1);
        mTotalQty=mProduct.getProductQtyAvailable();
        //Toast.makeText(getActivity(),"Id="+mCustomerId,Toast.LENGTH_LONG).show();
    }

    /**
     * Description: Used for checking a product availability
     * @return: booleat result
     */
    public boolean isAvailable()
    {
        if(mProduct.getProductQtyAvailable()<=0)
            return false;
       return true;
    }

    /**
     * Description: used for getting car details
     */
    public void getCartList()
    {
        mCartlist=mDatabaseCaller.getCartList(mCustomerId);
    }

    /**
     * Description:updates the status of product
     *
     */
    public void updateStatus()
    {
        if(isAvailable())
        {
            mStatusText.setText("Available (Qty:"+mProduct.getProductQtyAvailable()+")");
        }
        else
        {
            mStatusText.setText( R.string.outOfStock);
        }
    }

    /**
     *
     * Description: Used for initializing the views
     * @param view: View object
     */
    public void initViews(View view)
    {
        mNameText= (TextView) view.findViewById(R.id.detailsNameText);
        mPriceText= (TextView) view.findViewById(R.id.detailsPriceText);
        mDescriptionText= (TextView) view.findViewById(R.id.detailsDescText);
        mStatusText=(TextView) view.findViewById(R.id.detailsStatusText);
        //mDescriptionText= (TextView) view.findViewById(R.id.detailsDescriptionText);
       // mReviewListView= (ListView) view.findViewById(R.id.reviewList);
        mProductImageView= (ImageView) view.findViewById(R.id.detailsImageView);
        mPincodeEdit = (EditText) view.findViewById(R.id.pincode);
        mReviewEdit= (EditText) view.findViewById(R.id.detailsReviewEdit);
        mBuyButton= (Button) view.findViewById(R.id.buttonBuy);
        mSubmitReviewButton= (Button) view.findViewById(R.id.detailsButtonReview);
        mAddToCartButton= (Button) view.findViewById(R.id.buttonAddToCart);
        mAddToWishListButton= (Button) view.findViewById(R.id.buttonAddToWishlist);

        mShowReviewButton= (Button) view.findViewById(R.id.detailsButtonShowReview);
        mCheckPin = (Button) view.findViewById(R.id.buttonCheckDelivery);
        setListener();
        File folder =getActivity().getExternalFilesDir("contactimages");

        File file=new File(folder,mProduct.getProductImagePath());
        Log.d("path", file.getAbsolutePath());
        mProductImageView.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
        mNameText.setText(mProduct.getProductName());
        mPriceText.setText(String.valueOf(mProduct.getProductPrice()));
        mDescriptionText.setText(mProduct.getProductDescription());
      // mDescriptionText.setText(String.valueOf(mProduct.get()));
        //mReviewListView.setDividerHeight(2);
        //mReviewListView.setAdapter(new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,s));
        mNoOfItems=0;
        if(!getActivity().getSharedPreferences("login",Context.MODE_PRIVATE).getString("userid","").equals("")) {
            isProductExists(mCustomerId, mProduct.getProductId());
            mProduct.setProductQtyAvailable(mTotalQty);
        }
        mProduct.setProductQtyAvailable(mProduct.getProductQtyAvailable()-mNoOfItems);
       updateStatus();
    }

    /**
     * Description: Used for setting listeners
     */
    private void setListener() {
        mCheckPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!mPincodeEdit.getText().toString().isEmpty()){
                    if(mPincodeEdit.getText().toString().length()!=6)
                    {
                        mPincodeEdit.setError(getString(R.string.ValidPincode));

                    }
                    else {
                        if (isPinAvailable(mPincodeEdit.getText().toString())) {
                            mPincodeEdit.setError(Html.fromHtml("<font color='green'>item is available</font>"));
                        } else {
                            mPincodeEdit.setError(getString(R.string.itemNotAvailable));
                        }
                    }
                }
                else {
                    mPincodeEdit.setError(getString(R.string.pincodeEnter));
                }
            }
        });
        mAddToCartButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //checking whether user is already logged in
            if(getActivity().getSharedPreferences("login", Context.MODE_PRIVATE).getString("userid","").equals("")) {
                mainActivity.changeFragment(LoginFragment.class, null, true, LoginFragment.class.getName());

                //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new LoginFragment(), "login").addToBackStack("details").commit();
            }
            else {
                if(isAvailable()) {

                    if (isProductExists(mCustomerId, mProduct.getProductId())) {
                      //  mEshopSqlHelper.updateCartNoOfItems(mNoOfItems + 1, CartTable.CART_CUSTOMER_NO + "=? AND " + CartTable.CART_PRODUCT_CODE + "=?", new String[]{String.valueOf(getCustomerId()), String.valueOf(mProduct.getProductId())});
                    mDatabaseCaller.updateProduct(mNoOfItems+1,mCustomerId,mProduct.getProductId());
                    } else {
                        mDatabaseCaller.insertCartDetails(mCustomerId,mProduct.getProductId());
                        //getActivity().getMenuInflater().inflate(R.menu.menu_main,menu);
                        getCartList();
                        View view1 = MainActivity.sMenuItem.getActionView();
                        TextView txt = (TextView) view1.findViewById(R.id.noOfCartItems);
                        txt.setText("" + mCartlist.size());
                    }
                    mProduct.setProductQtyAvailable(mProduct.getProductQtyAvailable() - 1);
                    updateStatus();
                    Toast.makeText(getActivity(), R.string.cart, Toast.LENGTH_LONG).show();

                }
                else
                {
                    Toast.makeText(getActivity(), R.string.outOfStock,Toast.LENGTH_LONG).show();
                }
            }
        }
    });
        mBuyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //checking whether user is already logged in
                if(getActivity().getSharedPreferences("login",Context.MODE_PRIVATE).getString("userid","").equals("")) {
                    mainActivity.changeFragment(LoginFragment.class, null, true, LoginFragment.class.getName());

                    //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new LoginFragment(), "login").addToBackStack("details").commit();
                }
                else {
                    if(isAvailable()) {

                        if (isProductExists(mCustomerId, mProduct.getProductId())) {
                            mDatabaseCaller.updateProduct(mNoOfItems + 1, mCustomerId, mProduct.getProductId());
                        } else {
                            mDatabaseCaller.insertCartDetails(mCustomerId,mProduct.getProductId());
                            //getActivity().getMenuInflater().inflate(R.menu.menu_main,menu);
                            getCartList();
                            View view1 = MainActivity.sMenuItem.getActionView();
                            TextView txt = (TextView) view1.findViewById(R.id.noOfCartItems);
                            txt.setText("" + mCartlist.size());
                        }
                        mProduct.setProductQtyAvailable(mProduct.getProductQtyAvailable() - 1);
                        updateStatus();
                        mainActivity.changeFragment(ShipingFragment.class, null, true, ShipingFragment.class.getName());

                        //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new ShipingFragment(), "shiping").addToBackStack("details").commit();

                    }
                    else
                    {
                        Toast.makeText(getActivity(), R.string.outOfStock,Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
        mAddToWishListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //checking whether user is already logged in
                if(getActivity().getSharedPreferences("login",Context.MODE_PRIVATE).getString("userid","").equals("")) {
                    mainActivity.changeFragment(LoginFragment.class, null, true, LoginFragment.class.getName());

                    //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new LoginFragment(), "login").addToBackStack("details").commit();
                }
                else {
                    if (mDatabaseCaller.isProductExistsWishlist(mCustomerId, mProduct.getProductId())) {
                        Toast.makeText(getActivity(), R.string.alreadyInWishlist, Toast.LENGTH_LONG).show();
                    } else {
                        mDatabaseCaller.insertWhishlistDetails(new WishList(mCustomerId,mProduct.getProductId()));
                        //getActivity().getMenuInflater().inflate(R.menu.menu_main,menu);


                        Toast.makeText(getActivity(), R.string.wishlist,Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
        mShowReviewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getActivity().getSharedPreferences("login",Context.MODE_PRIVATE).getInt("custId",-1)!=-1) {

                    ReviewListDialogFragment mReviewListDialogFragment = new ReviewListDialogFragment();
                    Bundle bundle = new Bundle();
                    bundle.putInt("productid", mProduct.getProductId());
                    mReviewListDialogFragment.setArguments(bundle);
                    mReviewListDialogFragment.show(getActivity().getSupportFragmentManager(), "reviewlist");
                }
                else
                {
                    Toast.makeText(getActivity(), R.string.login,Toast.LENGTH_LONG).show();

                }
            }
        });
        mSubmitReviewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(getActivity().getSharedPreferences("login",Context.MODE_PRIVATE).getInt("custId",-1)!=-1)
                {
                   if( mReviewEdit.getText().toString().isEmpty())
                       mReviewEdit.setError("Please enter some text");
                    else
                       mDatabaseCaller.insertReview(new Review(mCustomerId,mProduct.getProductId(),mReviewEdit.getText().toString()));
                }
                else
                {
                    Toast.makeText(getActivity(), R.string.login,Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

    }

    /**
     * Description: Checking Product Already Exists
     * @param customerId
     * @param productCode
     * @return
     */
    public boolean isProductExists(int customerId,int productCode)
    {
        ArrayList<Cart> cartArrayList;
        cartArrayList=mDatabaseCaller.getCartList(customerId,productCode);
        if(cartArrayList.size()>0) {
            mNoOfItems=cartArrayList.get(0).getNoOfItems();
            return true;
        }
        else
        {
            mNoOfItems=0;
        }
        return  false;
    }

    /**
     * Description: Used to check whether delivery is available
     * @param pin
     * @return
     */
    public boolean isPinAvailable(String pin){
        boolean flag = false;
        pincodeArray = getActivity().getResources().getStringArray(R.array.pincodes);
        for (int i=0;i<pincodeArray.length;i++) {
            if (pincodeArray[i].equals(pin)) {
                flag = true;
                break;
            }
        }
        return flag;
    }
}
