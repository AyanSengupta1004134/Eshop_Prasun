package com.tcs.eshop.adapter;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.tcs.eshop.EshopClasses.Cart;
import com.tcs.eshop.EshopClasses.Customer;
import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.EshopClasses.WishList;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.utilities.DatabaseCaller;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by 986719 on 9/17/2015.
 */
public class WishlistAdapter extends BaseAdapter {
    Context context;
    Customer mCustomer;
    Product mProduct;
     ArrayList<WishList> mWishListArrayList;
     ArrayList<Cart> mCartlist;
     ArrayList<Product> mProductList;
    ImageView mProductImage, mDeleteProductImage, mAddProductToCart;
    TextView mProductNameText, mProductPriceText;
    DatabaseCaller mDatabaseCaller;
    int mNoOfItems;
    int mCustomerId;
    WishlistAdapter mWishlistAdapter;
    public WishlistAdapter(Context context) {
        mWishlistAdapter=this;
        this.context = context;
        mCustomerId=context.getSharedPreferences("login", Context.MODE_PRIVATE).getInt("custId", -1);
        mDatabaseCaller=new DatabaseCaller((MainActivity)context);
        mProductList = new ArrayList<>();
        mWishListArrayList =mDatabaseCaller.getWishList(mCustomerId);
        fetchProductList();
        Log.d("list", "2st:" + mWishListArrayList.size());
        Log.d("list", "ist:" + mProductList.size());
        //final String CART_JOIN = "SELECT * FROM "+CartTable.CART_TABLE+","+ProductTable.PRODUCT_TABLE+"WHERE "+CartTable.CART_CUSTOMER_NO+"="+mCustomer.getCustId()
        //      +" AND "+CartTable.CART_PRODUCT_CODE+"="+ProductTable.PRODUCT_ID;

    }

    public Context getContext() {
        return context;
    }

    public ArrayList<WishList> getmWishListArrayList() {
        return mWishListArrayList;
    }

    public ArrayList<Cart> getmCartlist() {
        return mCartlist;
    }

    public ArrayList<Product> getmProductList() {
        return mProductList;
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        mProductList = new ArrayList<>();
        mWishListArrayList =mDatabaseCaller.getWishList(mCustomerId);
        fetchProductList();
        Log.d("list", "2st:" + mWishListArrayList.size());
        Log.d("list", "ist:" + mProductList.size());

    }

    public void fetchProductList() {
        for (int i = 0; i < mWishListArrayList.size(); i++) {
            Log.d("list", "i:" + i);

            mProductList.add(i,mDatabaseCaller.getProduct(mWishListArrayList.get(i).getProductId()));
        }
    }



    @Override
    public int getCount() {
        return mWishListArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (view == null) {
            view = inflater.inflate(R.layout.wishlistsinglerow, viewGroup, false);
        }
        initViews(view, i);
        return view;
    }

    public void getCartList() {
        mCartlist =mDatabaseCaller.getCartList(mCustomerId);
    }

    public boolean isProductExists(int customerId, int productCode) {
        ArrayList<Cart> cartArrayList;
        cartArrayList=mDatabaseCaller.getCartList(customerId, productCode);
        if (cartArrayList.size() > 0) {
            mNoOfItems = cartArrayList.get(0).getNoOfItems();
            return true;
        }
        return false;
    }

    /**
     * Description: Used for initialising the views
     * @param view: View object
     * @param position: Row No
     */
    private void initViews(View view, final int position) {
        mProductNameText = (TextView) view.findViewById(R.id.wishListnameText);
        mProductPriceText = (TextView) view.findViewById(R.id.wishListpriceText);
        mProductImage = (ImageView) view.findViewById(R.id.wishlistProductImage);
        mDeleteProductImage = (ImageView) view.findViewById(R.id.wishListimageDelete);
        mAddProductToCart = (ImageView) view.findViewById(R.id.wishListimageAddtoCart);
        mProductNameText.setText(mProductList.get(position).getProductName());
        mProductPriceText.setText("rs:" + String.valueOf(mProductList.get(position).getProductPrice()));
        File folder =context.getExternalFilesDir("contactimages");

        File file=new File(folder,mProductList.get(position).getProductImagePath());
        Log.d("path", file.getAbsolutePath());
        mProductImage.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
        setListener(position);

    }

    /**
     * Description: Used to set listeners
     * @param position: ListView Row no
     */
    private void setListener(final int position) {
        mDeleteProductImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDatabaseCaller.deleteWishListItems(mCustomerId, mProductList.get(position).getProductId());
                mWishlistAdapter.notifyDataSetChanged();

            }
        });

        mAddProductToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isProductExists(mCustomerId, mProductList.get(position).getProductId())) {
                    mDatabaseCaller.updateProduct(mNoOfItems + 1, mCustomerId, mProductList.get(position).getProductId());
                } else {
                    mDatabaseCaller.insertCartDetails(mCustomerId, mProductList.get(position).getProductId());
                    //getActivity().getMenuInflater().inflate(R.menu.menu_main,menu);
                    getCartList();
                    View view1 = MainActivity.sMenuItem.getActionView();
                    TextView txt = (TextView) view1.findViewById(R.id.noOfCartItems);
                    txt.setText("" + mCartlist.size());
                }
            }
        });
    }
}


