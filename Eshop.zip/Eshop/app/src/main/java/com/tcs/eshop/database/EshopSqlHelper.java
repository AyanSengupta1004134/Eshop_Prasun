package com.tcs.eshop.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import com.tcs.eshop.EshopClasses.Address;
import com.tcs.eshop.EshopClasses.Cart;
import com.tcs.eshop.EshopClasses.Customer;
import com.tcs.eshop.EshopClasses.Payment;
import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.EshopClasses.Customer;
import com.tcs.eshop.EshopClasses.Review;
import com.tcs.eshop.EshopClasses.WishList;
import com.tcs.eshop.utilities.ApplicationConstant;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.ProductTable;
import com.tcs.eshop.EshopClasses.DisplayToast;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.CustomerTable;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.ReviewTable;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.*;

import java.util.ArrayList;

/**
 * Created by 986719 on 9/17/2015.
 */
public class EshopSqlHelper extends SQLiteOpenHelper {
    Context context;
    private static EshopSqlHelper sEshopSqlHelper=null;
    public static SQLiteDatabase sSqLiteDatabase=null;
    private EshopSqlHelper(Context context) {
        super(context, DataBaseConstant.DATABASE_NAME,null,DataBaseConstant.DATA_BASE_VERSION);
        this.context=context;

    }
    public static EshopSqlHelper getInstance(Context context) {
        if (sEshopSqlHelper == null) {
            sEshopSqlHelper = new EshopSqlHelper(context);
            sSqLiteDatabase=sEshopSqlHelper.getWritableDatabase();
        }
        return sEshopSqlHelper;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
       // Toast.makeText(context, "On Create", Toast.LENGTH_SHORT).show();
        try {
            sqLiteDatabase.execSQL(ProductTable.CREATE_PRODUCT_TABLE);
            sqLiteDatabase.execSQL(CustomerTable.CREATE_CUSTOMER_TABLE);
            sqLiteDatabase.execSQL(ReviewTable.CREATE_RVIEW_TABLE);
        //    Toast.makeText(context, "On Create Review Successful", Toast.LENGTH_LONG).show();
            Log.d("create", CartTable.CREATE_CART_TABLE);
            sqLiteDatabase.execSQL(CartTable.CREATE_CART_TABLE);
            sqLiteDatabase.execSQL(WishlistTable.CREATE_WISHLIST_TABLE);
            Log.d("create", AddressTable.CREATE_ADDRESS_TABLE);
            sqLiteDatabase.execSQL(AddressTable.CREATE_ADDRESS_TABLE);
            sqLiteDatabase.execSQL(PaymentTable.CREATE_PAYMENT_TABLE);
          //  Toast.makeText(context, "On Create Successful", Toast.LENGTH_LONG).show();
        }
        catch(SQLException e)
        {
            Log.d("EXCEPTION",""+e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
       // Toast.makeText(context, "On Upgrade", Toast.LENGTH_SHORT).show();
        try {
            sqLiteDatabase.execSQL(ProductTable.DROP_PRODUCT_TABLE);

            sqLiteDatabase.execSQL(CustomerTable.DROP_CUSTOMER_TABLE);
            sqLiteDatabase.execSQL(ReviewTable.DROP_REVIEW_TABLE);
            sqLiteDatabase.execSQL(CartTable.DROP_CART_TABLE);
            sqLiteDatabase.execSQL(WishlistTable.DROP_WISHLIST_TABLE);
            sqLiteDatabase.execSQL(AddressTable.DROP_ADDRESS_TABLE);
            sqLiteDatabase.execSQL(PaymentTable.DROP_PAYMENT_TABLE);

            onCreate(sqLiteDatabase);

        }
        catch(SQLException e)
        {
            Log.d("EXCEPTION",""+e);
        }
    }
    public void insertTable(Product product)
    {
        sSqLiteDatabase=this.getWritableDatabase();
        long rowNo;
        ContentValues contentValues=new ContentValues();
        contentValues.put(ProductTable.PRODUCT_NAME,product.getProductName());
        contentValues.put(ProductTable.PRODUCT_CATEGORY,product.getProductCategory());
        contentValues.put(ProductTable.PRODUCT_SUBCATEGORY,product.getProductSubCategory());
        contentValues.put(ProductTable.PRODUCT_PRICE,product.getProductPrice());
        contentValues.put(ProductTable.PRODUCT_IMAGE,product.getProductImagePath());
        contentValues.put(ProductTable.PRODUCT_QTY_AVAILABLE,product.getProductQtyAvailable());
        contentValues.put(ProductTable.PRODUCT_DESCRIPTION,product.getProductDescription());
        rowNo=sSqLiteDatabase.insert(ProductTable.PRODUCT_TABLE,ProductTable.PRODUCT_NAME,contentValues);
        // DisplayToast.showToast("Insearted row no:"+rowNo,context);
        //Toast.makeText(context, "Row no:"+rowNo, Toast.LENGTH_SHORT).show();
        sSqLiteDatabase.close();
    }
    public ArrayList<Product> selectTable(String whereCondition,String whereArgs[])
    {
        sSqLiteDatabase=this.getReadableDatabase();
        ArrayList<Product> productList=new ArrayList<Product>();
        int productIdIndex,productNameIndex,productCategoryIndex,productSubCategoryIndex,productPriceIndex,productImageIndex,productQtyAvailableIndex,productDescriptionIndex;
        String columnNames[]={ProductTable.PRODUCT_ID,ProductTable.PRODUCT_NAME,ProductTable.PRODUCT_CATEGORY,
                ProductTable.PRODUCT_SUBCATEGORY,ProductTable.PRODUCT_PRICE,
                ProductTable.PRODUCT_IMAGE,ProductTable.PRODUCT_QTY_AVAILABLE,ProductTable.PRODUCT_DESCRIPTION};
        Cursor cursor=sSqLiteDatabase.query(ProductTable.PRODUCT_TABLE,columnNames,whereCondition,whereArgs,null,null,null);
        productIdIndex=cursor.getColumnIndex(ProductTable.PRODUCT_ID);
        productNameIndex=cursor.getColumnIndex(ProductTable.PRODUCT_NAME);
        productCategoryIndex=cursor.getColumnIndex(ProductTable.PRODUCT_CATEGORY);
        productSubCategoryIndex=cursor.getColumnIndex(ProductTable.PRODUCT_SUBCATEGORY);
        productPriceIndex=cursor.getColumnIndex(ProductTable.PRODUCT_PRICE);
        productImageIndex=cursor.getColumnIndex(ProductTable.PRODUCT_IMAGE);
        productQtyAvailableIndex=cursor.getColumnIndex(ProductTable.PRODUCT_QTY_AVAILABLE);
        productDescriptionIndex=cursor.getColumnIndex(ProductTable.PRODUCT_DESCRIPTION);

        while(cursor.moveToNext())
        {
            productList.add(new Product(cursor.getInt(productIdIndex),cursor.getString(productNameIndex),cursor.getString(productCategoryIndex),
                    cursor.getString(productSubCategoryIndex),cursor.getFloat(productPriceIndex),cursor.getString(productImageIndex),
                    cursor.getInt(productQtyAvailableIndex),cursor.getString(productDescriptionIndex)));
        }
        cursor.close();
        sSqLiteDatabase.close();
        return productList;
    }
    public void updateProductNoOfItems(int noOfItems,String where,String whereArgs[])
    {
        sSqLiteDatabase=this.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put(ProductTable.PRODUCT_QTY_AVAILABLE, noOfItems);

        int row=sSqLiteDatabase.update(ProductTable.PRODUCT_TABLE,values,where,whereArgs);
        Log.d("update", "updated no:" + row);

    }
    public int getRowCount(String whereCondition,String whereArgs[]) {
        sSqLiteDatabase = this.getReadableDatabase();
        int productIdIndex, productNameIndex, productCategoryIndex, productSubCategoryIndex, productPriceIndex, productImageIndex, productQtyAvailableIndex, productDescriptionIndex;
        String columnNames[] = {ProductTable.PRODUCT_ID, ProductTable.PRODUCT_NAME, ProductTable.PRODUCT_CATEGORY,
                ProductTable.PRODUCT_SUBCATEGORY, ProductTable.PRODUCT_PRICE,
                ProductTable.PRODUCT_IMAGE, ProductTable.PRODUCT_QTY_AVAILABLE, ProductTable.PRODUCT_DESCRIPTION};
        Cursor cursor = sSqLiteDatabase.query(ProductTable.PRODUCT_TABLE, columnNames, whereCondition, whereArgs, null, null, null);
        return cursor.getCount();
    }
    public void insertCustomer(Customer customer){
       // SQLiteDatabase db = this.getWritableDatabase();
        sSqLiteDatabase=this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(CustomerTable.CUSTOMER_FIRST_NAME,customer.getFirstName());
        values.put(CustomerTable.CUSTOMER_LAST_NAME,customer.getLastName());
        values.put(CustomerTable.CUSTOMER_EMAIL_ID,customer.getEmailId());
        values.put(CustomerTable.CUSTOMER_PHONE_NO,customer.getPhoneNo());
        Log.d("insert", "" + customer.getQuestion());
        values.put(CustomerTable.CUSTOMER_QUESTION,customer.getQuestion());
        values.put(CustomerTable.CUSTOMER_ANSWER,customer.getAnswer());
        values.put(CustomerTable.CUSTOMER_PASSWORD, customer.getPassword());
        long count = sSqLiteDatabase.insert(CustomerTable.CUSTOMER_TABLE, null, values);
        //Toast.makeText(context,"count....."+count,Toast.LENGTH_LONG).show();
        sSqLiteDatabase.close();
    }

    public void deleteCustomer(int custId){
        sSqLiteDatabase=this.getWritableDatabase();
        sSqLiteDatabase.delete(CustomerTable.CUSTOMER_TABLE, CustomerTable.CUSTOMER_ID + " = ? ", new String[]{String.valueOf(custId)});
        sSqLiteDatabase.delete(CartTable.CART_TABLE, CartTable.CART_CUSTOMER_NO + " = ? ", new String[]{String.valueOf(custId)});
        sSqLiteDatabase.delete(WishlistTable.WISH_LIST_TABLE, WishlistTable.WISHLIST_CUSTOMER_NO + "=?", new String[]{String.valueOf(custId)});
        sSqLiteDatabase.delete(AddressTable.ADDRESS_TABLE, AddressTable.ADDRESS_CUSTOMER_NO + " = ? ", new String[]{String.valueOf(custId)});
        sSqLiteDatabase.delete(PaymentTable.PAYMENT_TABLE, PaymentTable.PAYMENT_CUSTOMER_NO + " = ? ", new String[]{String.valueOf(custId)});
        sSqLiteDatabase.delete(ReviewTable.REVIEW_TABLE, ReviewTable.REVIEW_CUSTOMER_NO + " = ? ", new String[]{String.valueOf(custId)});
        //Toast.makeText(context,"customer deleted",Toast.LENGTH_LONG).show();
    }
    public ArrayList<Customer> getAllCustomer(){
        ArrayList<Customer> customerList = new ArrayList<Customer>();
        //SQLiteDatabase db = getReadableDatabase();
        sSqLiteDatabase=this.getReadableDatabase();
        Cursor cursor = sSqLiteDatabase.rawQuery(DataBaseConstant.SELECT_CUSTOMER_TABLE, null);
        if(cursor.moveToFirst()){
            do{
                Customer cus = new Customer();
                cus.setCustId(cursor.getInt(0));
                cus.setFirstName(cursor.getString(1));
                cus.setLastName(cursor.getString(2));
                cus.setEmailId(cursor.getString(3));
                cus.setPhoneNo(cursor.getString(4));
                cus.setQuestion(cursor.getString(5));
                cus.setAnswer(cursor.getString(6));
                cus.setPassword(cursor.getString(7));
                customerList.add(cus);
            }while (cursor.moveToNext());

        }
        cursor.close();
        sSqLiteDatabase.close();
        return customerList;
    }
    public ArrayList<Customer> getAllCustomer(String where,String whereArgs[]){
        ArrayList<Customer> customerList = new ArrayList<Customer>();
        //SQLiteDatabase db = getReadableDatabase();
        sSqLiteDatabase=this.getReadableDatabase();
        String columnNames[]={CustomerTable.CUSTOMER_ID,CustomerTable.CUSTOMER_FIRST_NAME,CustomerTable.CUSTOMER_LAST_NAME,
                CustomerTable.CUSTOMER_EMAIL_ID,CustomerTable.CUSTOMER_PHONE_NO,CustomerTable.CUSTOMER_QUESTION,CustomerTable.CUSTOMER_ANSWER,
                CustomerTable.CUSTOMER_PASSWORD};
        Cursor cursor = sSqLiteDatabase.query(CustomerTable.CUSTOMER_TABLE, columnNames, where, whereArgs, null, null, null);
        if(cursor.moveToFirst()){
            do{
                Customer cus = new Customer();
                cus.setCustId(cursor.getInt(0));
                cus.setFirstName(cursor.getString(1));
                cus.setLastName(cursor.getString(2));
                cus.setEmailId(cursor.getString(3));
                cus.setPhoneNo(cursor.getString(4));
                cus.setQuestion(cursor.getString(5));
                cus.setAnswer(cursor.getString(6));
                cus.setPassword(cursor.getString(7));
                customerList.add(cus);
            }while (cursor.moveToNext());

        }
        cursor.close();
        sSqLiteDatabase.close();
        return customerList;
    }
    public void insertReview(Review review){
        sSqLiteDatabase=this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ReviewTable.REVIEW_CUSTOMER_NO,review.getCustomerId());
        values.put(ReviewTable.REVIEW_PRODUCT_CODE,review.getProductCode());
        values.put(ReviewTable.REVIEW_DETAIL,review.getUserReview());
        long rowNo = sSqLiteDatabase.insert(ReviewTable.REVIEW_TABLE, null, values);
        //Toast.makeText(context, "Row no:"+rowNo, Toast.LENGTH_SHORT).show();
        sSqLiteDatabase.close();
    }

    public ArrayList<Review> selectTableReviewTable(String whereCondition,String whereArgs[]){
        sSqLiteDatabase=this.getReadableDatabase();
        ArrayList<Review> reviewList=new ArrayList<Review>();
        int reviewIdIndex,reviewCustomerIdIndex,reviewProductIdIndex,reviewReviewDetailIndex;
        String columnNames[]={ReviewTable.REVIEW_ID, ReviewTable.REVIEW_CUSTOMER_NO,ReviewTable.REVIEW_PRODUCT_CODE,
                ReviewTable.REVIEW_DETAIL};
        Cursor cursor=sSqLiteDatabase.query(ReviewTable.REVIEW_TABLE,columnNames,whereCondition,whereArgs,null,null,null);
        reviewIdIndex=cursor.getColumnIndex(ReviewTable.REVIEW_ID);
        reviewCustomerIdIndex=cursor.getColumnIndex(ReviewTable.REVIEW_CUSTOMER_NO);
        reviewProductIdIndex=cursor.getColumnIndex(ReviewTable.REVIEW_PRODUCT_CODE);
        reviewReviewDetailIndex=cursor.getColumnIndex(ReviewTable.REVIEW_DETAIL);
        while(cursor.moveToNext())
        {
            reviewList.add(new Review(cursor.getInt(reviewIdIndex),cursor.getInt(reviewCustomerIdIndex),cursor.getInt(reviewProductIdIndex),
                    cursor.getString(reviewReviewDetailIndex)));
        }
        cursor.close();
        sSqLiteDatabase.close();
        return reviewList;
    }
    public void insertCartTable(Cart cart){
        sSqLiteDatabase=this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(CartTable.CART_CUSTOMER_NO,cart.getCustomerId());
        values.put(CartTable.CART_PRODUCT_CODE,cart.getProductCode());
        values.put(CartTable.CART_NO_OF_ITEMS,cart.getNoOfItems());
        long rowNo = sSqLiteDatabase.insert(CartTable.CART_TABLE, null, values);
        //Toast.makeText(context, "Row no:"+rowNo, Toast.LENGTH_SHORT).show();
        sSqLiteDatabase.close();
    }

    public ArrayList<Cart> selectTableCartTable(String whereCondition,String whereArgs[]){
        sSqLiteDatabase=this.getReadableDatabase();
        ArrayList<Cart> cartList=new ArrayList<Cart>();
        int cartCustomerIdIndex,cartProductNoIndex,cartNoOfItemsIndex;
        String columnNames[]={CartTable.CART_CUSTOMER_NO,CartTable.CART_PRODUCT_CODE,CartTable.CART_NO_OF_ITEMS};
        Cursor cursor=sSqLiteDatabase.query(CartTable.CART_TABLE,columnNames,whereCondition,whereArgs,null,null,null);
        cartCustomerIdIndex=cursor.getColumnIndex(CartTable.CART_CUSTOMER_NO);
        cartProductNoIndex=cursor.getColumnIndex(CartTable.CART_PRODUCT_CODE);
        cartNoOfItemsIndex=cursor.getColumnIndex(CartTable.CART_NO_OF_ITEMS);
        while(cursor.moveToNext())
        {
            cartList.add(new Cart(cursor.getInt(cartCustomerIdIndex),cursor.getInt(cartProductNoIndex),cursor.getInt(cartNoOfItemsIndex)));
        }
        cursor.close();
        sSqLiteDatabase.close();
        return cartList;
    }
    public void updateCartNoOfItems(int noOfItems,String where,String whereArgs[])
    {
        sSqLiteDatabase=this.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put(CartTable.CART_NO_OF_ITEMS, noOfItems);

        int row=sSqLiteDatabase.update(CartTable.CART_TABLE,values,where,whereArgs);
        Log.d("update", "updated no:" + row);

    }
    public void deleteCartItem(String where,String whereArgs[])
    {
        sSqLiteDatabase=this.getWritableDatabase();

        int row=sSqLiteDatabase.delete(CartTable.CART_TABLE, where, whereArgs);
        Log.d("deleted", "Delete no:" + row);
    }
    public void insertWishListTable(WishList wishList){
        sSqLiteDatabase=this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WishlistTable.WISHLIST_CUSTOMER_NO,wishList.getCustomerId());
        values.put(WishlistTable.WISHLIST_PRODUCT_CODE,wishList.getProductId());
        long rowNo = sSqLiteDatabase.insert(WishlistTable.WISH_LIST_TABLE, null, values);
        //Toast.makeText(context, "Row no:"+rowNo, Toast.LENGTH_SHORT).show();
        sSqLiteDatabase.close();
    }
    public ArrayList<WishList> selectTableWishListTable(String whereCondition,String whereArgs[]){
        sSqLiteDatabase=this.getReadableDatabase();
        ArrayList<WishList> wishListArrayList=new ArrayList<WishList>();
        int wishlistCustomerIdIndex,wishlistProductNoIndex;
        String columnNames[]={WishlistTable.WISHLIST_CUSTOMER_NO,WishlistTable.WISHLIST_PRODUCT_CODE};
        Cursor cursor=sSqLiteDatabase.query(WishlistTable.WISH_LIST_TABLE,columnNames,whereCondition,whereArgs,null,null,null);
        wishlistCustomerIdIndex=cursor.getColumnIndex(WishlistTable.WISHLIST_CUSTOMER_NO);
        wishlistProductNoIndex=cursor.getColumnIndex(WishlistTable.WISHLIST_PRODUCT_CODE);
        while(cursor.moveToNext())
        {
            wishListArrayList.add(new WishList(cursor.getInt(wishlistCustomerIdIndex),cursor.getInt(wishlistProductNoIndex)));
        }
        cursor.close();
        sSqLiteDatabase.close();
        return wishListArrayList;
    }
    public void deleteWishListItem(String where,String whereArgs[])
    {
        sSqLiteDatabase=this.getWritableDatabase();

        int row=sSqLiteDatabase.delete(WishlistTable.WISH_LIST_TABLE, where, whereArgs);
        Log.d("deleted", "Delete no:" + row);
    }
    public void insertAddressTable(Address address){
        sSqLiteDatabase=this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(AddressTable.ADDRESS_CUSTOMER_NO,address.getCustomerId());
        values.put(AddressTable.ADDRESS_CUSTOMER_NAME,address.getName());
        values.put(AddressTable.ADDRESS_CUSTOMER_ADDRESS,address.getAddress());
        values.put(AddressTable.ADDRESS_CUSTOMER_PIN,address.getPincode());
        values.put(AddressTable.ADDRESS_CUSTOMER_PHONE_NO,address.getPhoneNo());
        values.put(AddressTable.ADDRESS_CUSTOMER_CITY,address.getCity());
        values.put(AddressTable.ADDRESS_CUSTOMER_STATE,address.getState());
        long rowNo = sSqLiteDatabase.insert(AddressTable.ADDRESS_TABLE, null, values);
        //Toast.makeText(context, "Row no:"+rowNo, Toast.LENGTH_SHORT).show();
        sSqLiteDatabase.close();
    }
    public ArrayList<Address> selectTableAddressTable(String whereCondition,String whereArgs[]){
        sSqLiteDatabase=this.getReadableDatabase();
        ArrayList<Address> addressesArrayList=new ArrayList<Address>();
        int addressIdIndex,addressCustIdIndex,addressNameIndex,addressAddressIndex,addressPincodeIndex,addressPhoneNoIndex,addressCityIndex,addressStateIndex;
        String columnNames[]={AddressTable.ADDRESS_ID,AddressTable.ADDRESS_CUSTOMER_NO,AddressTable.ADDRESS_CUSTOMER_NAME,
                AddressTable.ADDRESS_CUSTOMER_ADDRESS,AddressTable.ADDRESS_CUSTOMER_PIN,AddressTable.ADDRESS_CUSTOMER_PHONE_NO,
                AddressTable.ADDRESS_CUSTOMER_CITY,AddressTable.ADDRESS_CUSTOMER_STATE};
        Cursor cursor=sSqLiteDatabase.query(AddressTable.ADDRESS_TABLE,columnNames,whereCondition,whereArgs,null,null,null);
        addressIdIndex=cursor.getColumnIndex(AddressTable.ADDRESS_ID);
        addressCustIdIndex=cursor.getColumnIndex(AddressTable.ADDRESS_CUSTOMER_NO);
        addressNameIndex=cursor.getColumnIndex(AddressTable.ADDRESS_CUSTOMER_NAME);
        addressAddressIndex=cursor.getColumnIndex(AddressTable.ADDRESS_CUSTOMER_ADDRESS);
        addressPincodeIndex=cursor.getColumnIndex(AddressTable.ADDRESS_CUSTOMER_PIN);
        addressPhoneNoIndex=cursor.getColumnIndex(AddressTable.ADDRESS_CUSTOMER_PHONE_NO);
        addressCityIndex=cursor.getColumnIndex(AddressTable.ADDRESS_CUSTOMER_CITY);
        addressStateIndex=cursor.getColumnIndex(AddressTable.ADDRESS_CUSTOMER_STATE);
        while(cursor.moveToNext())
        {
            addressesArrayList.add(new Address(cursor.getInt(addressIdIndex),cursor.getInt(addressCustIdIndex),cursor.getString(addressNameIndex),
                    cursor.getString(addressAddressIndex),cursor.getInt(addressPincodeIndex),cursor.getString(addressPhoneNoIndex),cursor.getString(addressCityIndex),cursor.getString(addressStateIndex)));
        }
        cursor.close();
        sSqLiteDatabase.close();
        return addressesArrayList;
    }
    public void insertPaymentDetail(Payment payment){
        // SQLiteDatabase db = this.getWritableDatabase();
        sSqLiteDatabase=this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PaymentTable.PAYMENT_CUSTOMER_NO,payment.getCustId());
        values.put(PaymentTable.CARD_NUMBER, payment.getCardNumber());
        values.put(PaymentTable.CARD_TYPE,payment.getCardType());
        values.put(PaymentTable.EXPIRY_MONTH,payment.getExpiryMonth());
        values.put(PaymentTable.EXPIRY_YEAR,payment.getExpiryYear());

        long count = sSqLiteDatabase.insert(PaymentTable.PAYMENT_TABLE, null, values);
        //Toast.makeText(context,"row="+count,Toast.LENGTH_LONG).show();
        sSqLiteDatabase.close();
    }
    public void deleteCardDetails(String where,String whereArgs[])
    {
        sSqLiteDatabase=this.getWritableDatabase();

        int row=sSqLiteDatabase.delete(PaymentTable.PAYMENT_TABLE, where, whereArgs);
        Log.d("deleted", "Delete no:" + row);
    }
    public ArrayList<Payment> selectTablePaymentTable(String whereCondition,String whereArgs[]){
        sSqLiteDatabase=this.getReadableDatabase();
        ArrayList<Payment> cardArrayList=new ArrayList<Payment>();
        int paymentCustIdIndex,paymentCardNoIndex,paymentCardTypeIndex,paymentExpiryMonthIndex,paymentExpiryYearIndex;
        String columnNames[]={PaymentTable.PAYMENT_CUSTOMER_NO,PaymentTable.CARD_NUMBER,PaymentTable.CARD_TYPE,
                PaymentTable.EXPIRY_MONTH,PaymentTable.EXPIRY_YEAR};
        Cursor cursor=sSqLiteDatabase.query(PaymentTable.PAYMENT_TABLE,columnNames,whereCondition,whereArgs,null,null,null);
        paymentCustIdIndex=cursor.getColumnIndex(PaymentTable.PAYMENT_CUSTOMER_NO);
        paymentCardNoIndex=cursor.getColumnIndex(PaymentTable.CARD_NUMBER);
        paymentCardTypeIndex=cursor.getColumnIndex(PaymentTable.CARD_TYPE);
        paymentExpiryMonthIndex=cursor.getColumnIndex(PaymentTable.EXPIRY_MONTH);
        paymentExpiryYearIndex=cursor.getColumnIndex(PaymentTable.EXPIRY_YEAR);
        while(cursor.moveToNext())
        {
            cardArrayList.add(new Payment(cursor.getInt(paymentCustIdIndex),cursor.getString(paymentCardNoIndex),
                    cursor.getString(paymentCardTypeIndex),cursor.getString(paymentExpiryMonthIndex),cursor.getString(paymentExpiryYearIndex)));
        }
        cursor.close();
        sSqLiteDatabase.close();
        return cardArrayList;
    }
    public boolean checkCustomer(String u_id)
    {
        boolean result=false;
       // SQLiteDatabase db = this.getReadableDatabase();
        sSqLiteDatabase=this.getReadableDatabase();
        Cursor cursor=sSqLiteDatabase.query( DataBaseConstant.CUSTOMER_TABLE, new String[]{CustomerTable.CUSTOMER_ID}, CustomerTable.CUSTOMER_PHONE_NO + " = ? or " + CustomerTable.CUSTOMER_EMAIL_ID + " = ? ", new String[]{u_id, u_id}, null, null, null);
        if(cursor.getCount()>0)
        {
            cursor.moveToFirst();
            do
            {
                result=true;
            }while (cursor.moveToNext());
        }

        cursor.close();
        sSqLiteDatabase.close();;
        return result;
    }
    public boolean loginCustomer(String u_id,String pswd)
    {
        boolean result=false;
       // SQLiteDatabase db = this.getReadableDatabase();
        sSqLiteDatabase=this.getWritableDatabase();
        Cursor cursor=sSqLiteDatabase.query( CustomerTable.CUSTOMER_TABLE, new String[]{CustomerTable.CUSTOMER_ID}, CustomerTable.CUSTOMER_PHONE_NO+ " = ? or "+ CustomerTable.CUSTOMER_EMAIL_ID+ " = ? and "+ CustomerTable.CUSTOMER_PASSWORD+ " = ? ", new String[]{u_id,u_id,pswd},null, null, null);
        if(cursor.getCount()>0)
        {
            cursor.moveToFirst();
            do
            {
                result=true;
            }while (cursor.moveToNext());
        }

        cursor.close();
        sSqLiteDatabase.close();;
        return result;
    }
    public String getSecurityQuestion(String u_id)
    {
        String question=null;
        //SQLiteDatabase db = this.getReadableDatabase();
        sSqLiteDatabase=this.getWritableDatabase();
        Cursor cursor=sSqLiteDatabase.query( CustomerTable.CUSTOMER_TABLE, new String[]{CustomerTable.CUSTOMER_QUESTION}, CustomerTable.CUSTOMER_PHONE_NO + " = ? or " + CustomerTable.CUSTOMER_EMAIL_ID + " = ? ", new String[]{u_id, u_id}, null, null, null);
        if(cursor.getCount()>0)
        {
            cursor.moveToFirst();
            do
            {
                int  index=cursor.getColumnIndex(CustomerTable.CUSTOMER_QUESTION);
                question=cursor.getString(index);
            }while (cursor.moveToNext());
        }

        cursor.close();
        sSqLiteDatabase.close();;
        return question;
    }

    public Boolean matchAnswer(String u_id,String mAnswer) {
        boolean result=false;
       // SQLiteDatabase db = this.getReadableDatabase();
        sSqLiteDatabase=this.getReadableDatabase();
        Cursor cursor=sSqLiteDatabase.query( CustomerTable.CUSTOMER_TABLE, new String[]{CustomerTable.CUSTOMER_ID}, CustomerTable.CUSTOMER_PHONE_NO+ " = ? or "+ CustomerTable.CUSTOMER_EMAIL_ID+ " = ? and "+ CustomerTable.CUSTOMER_ANSWER+ " = ? ", new String[]{u_id,u_id,mAnswer},null, null, null);
        if(cursor.getCount()>0)
        {
            cursor.moveToFirst();
            do
            {
                result=true;
            }while (cursor.moveToNext());
        }

        cursor.close();
        sSqLiteDatabase.close();;
        return result;
    }
    public Boolean updatePassword(String u_id,String pswd) {
        boolean result=false;
      //  SQLiteDatabase db = this.getWritableDatabase();
        sSqLiteDatabase=this.getWritableDatabase();
        ContentValues values = new ContentValues();
        Log.d("updating","new password");
        Log.d("up",""+pswd);
        values.put(CustomerTable.CUSTOMER_PASSWORD, pswd);
        if(sSqLiteDatabase.update(CustomerTable.CUSTOMER_TABLE , values , CustomerTable.CUSTOMER_PHONE_NO + " = ? or "+ CustomerTable.CUSTOMER_EMAIL_ID+ " = ? " , new String[]{u_id,u_id})>0);
        {result=true;}
        sSqLiteDatabase.close();;
        return result;
    }
}
