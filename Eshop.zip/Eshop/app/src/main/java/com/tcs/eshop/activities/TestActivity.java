package com.tcs.eshop.activities;

import android.app.Activity;
import android.os.Bundle;
import com.tcs.eshop.R;

/**
 * Created by 986719 on 9/16/2015.
 */
public class TestActivity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gridsingleitem);
    }
}
