package com.tcs.eshop.fragments;

/**
 * Created by 986719 on 9/18/2015.
 */



        import android.content.Context;
        import android.os.Bundle;
        import android.support.v4.app.Fragment;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;

        import com.tcs.eshop.activities.MainActivity;
        import com.tcs.eshop.database.EshopSqlHelper;
        import com.tcs.eshop.R;

        import org.w3c.dom.Text;

/**
 * Created by 963693 on 9/17/2015.
 */
public class ForgotPasswordFragment extends Fragment {
    private  TextView tvForgot;
    private  EditText etForgot;
    private Button btAnswer,btSubmit;
    private RegisterFragment shopNewRegister;;
    private LoginFragment shopLoginFragment;
    private  EshopSqlHelper mEshopSqlHelper;
    private Context mContext;
    private String mAnswer;
    public String mUserId;
    private TextView tvSecurityQ;
    private EditText etAnswerQ;
    MainActivity mainActivity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // super.onCreateView(inflater, container, savedInstanceState);
        View v = inflater.inflate(R.layout.forgot_password, container, false);
        mContext=container.getContext();
        mEshopSqlHelper=EshopSqlHelper.getInstance(getActivity());
        tvForgot=(TextView)v.findViewById(R.id.tvForget);
        etForgot=(EditText)v.findViewById(R.id.etForgot);
        tvSecurityQ=(TextView)v.findViewById(R.id.tvSecurityQues);
        etAnswerQ=(EditText)v.findViewById(R.id.etAnswer);
        btAnswer=(Button)v.findViewById(R.id.btAnswer);
        btSubmit=(Button)v.findViewById(R.id.btSubmit);
        shopNewRegister=new RegisterFragment();
        btSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean mFlag=validate(mContext);
                if(mFlag==false){
                    Boolean flag = mEshopSqlHelper.checkCustomer(mUserId);
                    if (flag == false) {
                        Toast.makeText(mContext, R.string.userIdDatabaseCheck, Toast.LENGTH_SHORT).show();
                    } else {
                        tvSecurityQ.setVisibility(View.VISIBLE);
                        String question=mEshopSqlHelper.getSecurityQuestion(mUserId);
                        tvSecurityQ.setText(mContext.getString(R.string.securityQuestion)+" "+question);
                        etAnswerQ.setVisibility(View.VISIBLE);
                        btAnswer.setVisibility(View.VISIBLE);
                        btSubmit.setVisibility(View.INVISIBLE);
                    }}}

        });
        btAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAnswer=etAnswerQ.getText().toString();
                Boolean mFlagNew=mEshopSqlHelper.matchAnswer(mUserId,mAnswer);
                if(mFlagNew)
                {
                    Bundle bundle=new Bundle();
                    bundle.putString("uid", etForgot.getText().toString());
                    //SetNewPwdFragment shopNewPswd = new SetNewPwdFragment();
                    //shopNewPswd.setArguments(bundle);
                    mainActivity.changeFragment(SetNewPwdFragment.class, bundle, true, SetNewPwdFragment.class.getName());

                    //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, shopNewPswd, "setnewpwd").addToBackStack("forgot").commit();

                }
                else
                    Toast.makeText(mContext, R.string.securityAnswer, Toast.LENGTH_SHORT).show();
            }
        });
        return v;
    }
    public boolean validate(Context context)
    {
        Boolean flag=false;
        mUserId = etForgot.getText().toString();
        if (mUserId.isEmpty()) {
            etForgot.setError(context.getString(R.string.mandatoryField));
            return true;
        }
        if (!shopLoginFragment.isNumeric(mUserId)) {
            if (!shopNewRegister.isValidMail(mUserId)) {
                etForgot.setError(context.getString(R.string.emailFormat));
                flag=true;
            }
        }
        else if (!shopNewRegister.isValidNo(mUserId)) {
            etForgot.setError(context.getString(R.string.phoneNoFormat));
            flag=true;
        }

        return  flag;
    }
}