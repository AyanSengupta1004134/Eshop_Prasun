package com.tcs.eshop.utilities;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.app.TaskStackBuilder;
import android.util.Log;
import android.widget.Toast;

import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;

/**
 * Created by 986719 on 9/25/2015.
 */
public class NetworkReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if(isConnected(context)&&!context.getSharedPreferences("payment", Context.MODE_PRIVATE).getString("pay", "").equals("")) {
            Intent resultIntent = new Intent(context, MainActivity.class);
            resultIntent.putExtra("isNotified",true);
            TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
            stackBuilder.addParentStack(MainActivity.class);

// Adds the Intent that starts the Activity to the top of the stack
            stackBuilder.addNextIntent(resultIntent);
            PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);

            Notification noti = new Notification.Builder(context)
                    .setContentTitle("Network Available Proceed With Payment")
                    .setSmallIcon(R.drawable.nav_logo_home)
                    .setContentIntent(resultPendingIntent)
                    .setAutoCancel(true)
                    .build();
            NotificationManager mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

// notificationID allows you to update the notification later on.
            mNotificationManager.notify(1, noti);
            Log.d("ajay", "fired");
            Toast.makeText(context, "Alarm....", Toast.LENGTH_LONG).show();
            context.getSharedPreferences("payment", Context.MODE_PRIVATE).edit().clear().commit();
        }
    }
    public boolean isConnected(Context context)
    {
        ConnectivityManager cm =
                (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();

    }
}
