package com.tcs.eshop.fragments;


import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.tcs.eshop.EshopClasses.Cart;
import com.tcs.eshop.EshopClasses.Customer;
import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.utilities.ApplicationConstant;
import com.tcs.eshop.utilities.DatabaseCaller;

import java.util.ArrayList;

/**
 * Created by 962609 on 9/21/2015.
 */
public class PaymentFragment extends Fragment {
    ListView listView_pay_option;
    String[] mPayOption;
    Context mContext;
    ArrayList<Customer> mCustomerList;
    EshopSqlHelper mEshopSqlHelper;
    int mCustId;
    DatabaseCaller mDatabaseCaller;
    MainActivity mainActivity;
    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
        mEshopSqlHelper= EshopSqlHelper.getInstance(getActivity());
        mCustId=getActivity().getSharedPreferences("login", Context.MODE_PRIVATE).getInt("custId", -1);
        mDatabaseCaller=new DatabaseCaller((MainActivity)getActivity());
        mPayOption=getResources().getStringArray(R.array.payment_options);
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.payment_layout, container, false);
        Log.d("payment fragment","hello");
        mContext=container.getContext();
        listView_pay_option=(ListView)view.findViewById(R.id.listView_pay_option);
        ArrayAdapter<String> mPayArrayAdapter =
                new ArrayAdapter<String>(mContext, android.R.layout.simple_list_item_1, mPayOption);
        listView_pay_option.setAdapter(mPayArrayAdapter);
        listView_pay_option.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               // PaymentDetailFragment paymentFragment = new PaymentDetailFragment();
                Bundle bundle = new Bundle();
                if (mPayOption[position].equals(getString(R.string.cashOnDelivery))) {
                    makeDispatch();
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

// set title
                    alertDialogBuilder.setTitle("Payment");

// set dialog message
                    alertDialogBuilder.setMessage("Thanks for shopping").setCancelable(true);

// create alert dialog
                    AlertDialog alertDialog = alertDialogBuilder.create();

// show it
                    alertDialog.setCanceledOnTouchOutside(true);
                    alertDialog.show();
                    mainActivity.changeFragment(HomeFragment.class, null, true, HomeFragment.class.getName());

                    // Toast.makeText(mContext,R.string.shopping +mDatabaseCaller.getCustomerName(mCustId),Toast.LENGTH_SHORT).show();
                } else {
                    bundle.putString("Card Type", mPayOption[position]);
                   // paymentFragment.setArguments(bundle);
                    mainActivity.changeFragment(PaymentDetailFragment.class, bundle, true, PaymentDetailFragment.class.getName());

                    //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, paymentFragment, "paymentdetails").addToBackStack("payment").commit();
                }
            }
        });

    return view;
    }
    /**
     * Description: Used for updating cart and product quantities
     */
    public void makeDispatch() {
        Product mProduct;
        ArrayList<Cart> cartArrayList = mDatabaseCaller.getCartList(mCustId);
        for(Cart c:cartArrayList)
        {
            mProduct=mDatabaseCaller.getProduct(c.getProductCode());
            mDatabaseCaller.updateProductNoOfItems(mProduct.getProductQtyAvailable() - c.getNoOfItems(), c.getProductCode());
            mDatabaseCaller.deleteCartItems(mCustId, c.getProductCode());
        }
        MainActivity mainActivity= (MainActivity) getActivity();

        mainActivity.getmCartText().setText("0");

    }

}
